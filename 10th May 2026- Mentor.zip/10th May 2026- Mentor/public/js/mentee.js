// ============================================
// MENTEE PAGES & FUNCTIONALITY
// ============================================

const MenteePages = {
  renderDashboard: () => {
    return `
      <div class="container">
        <div class="card">
          <div class="card-header">
            <h2>📚 Mentee Dashboard</h2>
            <p>Manage your queries and track their status</p>
          </div>
          
          <button class="btn btn-primary mb-3" onclick="MenteePages.showCreateQueryModal()">
            + Submit New Query
          </button>
          
          <div id="queriesContainer">
            <div class="text-center">
              <div class="loading"></div>
              <p>Loading your queries...</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Create Query Modal -->
      <div id="createQueryModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Submit New Query</h2>
            <button class="modal-close" onclick="ModalHelper.close('createQueryModal')">×</button>
          </div>
          
          <div class="modal-body">
            <form id="createQueryForm">
              <div class="form-group">
                <label for="employeeName">Employee Name</label>
                <input type="text" id="employeeName" name="employeeName" required>
              </div>
              
              <div class="form-group">
                <label for="employeeId">Employee ID</label>
                <input type="text" id="employeeId" name="employeeId" required>
              </div>
              
              <div class="form-group">
                <label for="questionTitle">Question Title</label>
                <input type="text" id="questionTitle" name="questionTitle" required>
              </div>
              
              <div class="form-row">
                <div class="form-group">
                  <label for="category">Category</label>
                  <select id="category" name="category" required>
                    <option value="">Select category</option>
                    <option value="Technical">Technical</option>
                    <option value="Career">Career</option>
                    <option value="Skills">Skills Development</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="complexity">Complexity Level</label>
                  <select id="complexity" name="complexity" required>
                    <option value="">Select complexity</option>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>
              
              <div class="form-row">
                <div class="form-group">
                  <label for="meetingType">Meeting Type</label>
                  <select id="meetingType" name="meetingType" required>
                    <option value="">Select meeting type</option>
                    <option value="video">Video Call</option>
                    <option value="audio">Audio Call</option>
                    <option value="chat">Chat</option>
                    <option value="email">Email</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="preferredSlot">Preferred Slot</label>
                  <input type="datetime-local" id="preferredSlot" name="preferredSlot" required>
                </div>
              </div>
              
              <div class="form-group">
                <label for="detailedQuery">Detailed Query Description</label>
                <textarea id="detailedQuery" name="detailedQuery" required placeholder="Provide detailed description of your query..."></textarea>
              </div>
            </form>
          </div>
          
          <div class="modal-footer">
            <button class="btn btn-secondary" onclick="ModalHelper.close('createQueryModal')">Cancel</button>
            <button class="btn btn-primary" onclick="MenteePages.handleCreateQuery()">Submit Query</button>
          </div>
        </div>
      </div>
    `;
  },

  showCreateQueryModal: () => {
    ModalHelper.open("createQueryModal");
  },

  handleCreateQuery: async () => {
    const formData = FormHelper.getFormData("createQueryForm");
    
    const errors = Validation.validateForm(formData);
    if (Object.keys(errors).length > 0) {
      Notification.error("Please fill in all required fields");
      return;
    }

    try {
      FormHelper.disableForm("createQueryForm", true);
      
      const response = await API.createQuery(formData);
      
      Notification.success("Query submitted successfully!");
      ModalHelper.close("createQueryModal");
      FormHelper.resetForm("createQueryForm");
      
      MenteePages.loadQueries();
    } catch (error) {
      handleError(error);
      FormHelper.disableForm("createQueryForm", false);
    }
  },

  loadQueries: async () => {
    try {
      const response = await API.getMyQueries();
      const container = document.getElementById("queriesContainer");
      
      if (!response.data || response.data.length === 0) {
        container.innerHTML = `
          <div class="text-center mt-4">
            <p class="text-muted">No queries submitted yet. Create your first query!</p>
          </div>
        `;
        return;
      }

      let html = '<div class="grid grid-2">';
      response.data.forEach(query => {
        const daysDiff = DateUtils.calculateDaysDiff(query.createdAt, query.closedAt || new Date());
        html += `
          <div class="card">
            <div class="flex-between mb-2">
              <h3>${query.questionTitle}</h3>
              <span class="badge badge-${query.status === 'CLOSED' ? 'danger' : query.status === 'RESOLVED' ? 'success' : 'primary'}">
                ${query.status}
              </span>
            </div>
            
            <div class="query-meta mb-2">
              <span>📂 ${query.category}</span>
              <span>⚙️ ${query.complexity}</span>
              <span>⏱️ ${daysDiff} days</span>
            </div>
            
            <p class="text-muted mb-2">${query.detailedQuery.substring(0, 100)}...</p>
            
            ${query.resolution ? `
              <div class="alert alert-success mb-2">
                <strong>Resolution:</strong> ${query.resolution.substring(0, 100)}...
              </div>
            ` : ''}
            
            <div class="text-muted text-small">
              Created: ${DateUtils.getRelativeTime(query.createdAt)}
            </div>
          </div>
        `;
      });
      html += '</div>';
      
      container.innerHTML = html;
    } catch (error) {
      handleError(error);
    }
  }
};

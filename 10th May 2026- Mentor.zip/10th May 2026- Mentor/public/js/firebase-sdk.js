const FirebaseSDK = (() => {
  const DEFAULT_USERS = [
    {
      id: "admin-default",
      email: "admin@example.com",
      password: "Admin@123",
      name: "Default Admin",
      employeeId: "ADMIN001",
      role: "ADMIN",
      department: "Administration",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: "mentor-default",
      email: "mentor@example.com",
      password: "Mentor@123",
      name: "Default Mentor",
      employeeId: "MENTOR001",
      role: "MENTOR",
      department: "Mentoring",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: "mentee-default",
      email: "mentee@example.com",
      password: "Mentee@123",
      name: "Default Mentee",
      employeeId: "MENTEE001",
      role: "MENTEE",
      department: "Learning",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];

  const DEFAULT_MENTORS = [
    { id: "mentor1", name: "John Smith", expertise: "Technical" },
    { id: "mentor2", name: "Sarah Johnson", expertise: "Career" },
    { id: "mentor3", name: "Mike Davis", expertise: "Skills Development" },
    { id: "mentor4", name: "Emily Brown", expertise: "General" }
  ];

  const STORAGE_KEYS = {
    users: "local-users",
    queries: "local-queries"
  };

  const isFirebaseConfigValid = () => {
    if (!firebaseConfig) return false;
    const values = Object.values(firebaseConfig);
    return values.every(value => typeof value === "string" && value.trim() !== "" && !value.includes("YOUR_"));
  };

  const useFirebase = isFirebaseConfigValid();

  const initFirebase = () => {
    if (!useFirebase) {
      return null;
    }

    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }
    return firebase;
  };

  const getAuth = () => {
    const app = initFirebase();
    return app ? app.auth() : null;
  };

  const getFirestore = () => {
    const app = initFirebase();
    return app ? app.firestore() : null;
  };

  const normalizeDoc = (doc) => ({ id: doc.id, ...doc.data() });

  const ensureLoggedIn = () => {
    const user = Storage.getUser();
    if (!user) {
      throw new Error("User is not logged in");
    }
    return user;
  };

  const getLocalUsers = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.users);
      return stored ? JSON.parse(stored) : [...DEFAULT_USERS];
    } catch (error) {
      return [...DEFAULT_USERS];
    }
  };

  const saveLocalUsers = (users) => {
    localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users));
  };

  const getLocalQueries = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.queries);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      return [];
    }
  };

  const saveLocalQueries = (queries) => {
    localStorage.setItem(STORAGE_KEYS.queries, JSON.stringify(queries));
  };

  const findLocalUser = (email, password) => {
    const normalizedEmail = email.trim().toLowerCase();
    return getLocalUsers().find(user => user.email.toLowerCase() === normalizedEmail && user.password === password);
  };

  const getMentorById = (mentorId) => DEFAULT_MENTORS.find(mentor => mentor.id === mentorId) || { id: mentorId, name: mentorId };

  const register = async (userData) => {
    const users = getLocalUsers();
    const normalizedEmail = userData.email.trim().toLowerCase();

    if (users.some(user => user.email.toLowerCase() === normalizedEmail)) {
      throw new Error("Email is already registered");
    }

    const newUser = {
      id: `local-${Date.now()}`,
      email: normalizedEmail,
      password: userData.password,
      name: userData.name,
      employeeId: userData.employeeId,
      role: userData.role,
      department: userData.department,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    users.push(newUser);
    saveLocalUsers(users);

    return {
      token: `local-token-${btoa(normalizedEmail)}`,
      user: newUser
    };
  };

  const login = async (email, password) => {
    if (useFirebase) {
      const auth = getAuth();
      if (!auth) {
        throw new Error("Firebase auth is not available");
      }
      const userCredential = await auth.signInWithEmailAndPassword(email, password);
      const profileDoc = await getFirestore().collection("users").doc(userCredential.user.uid).get();

      if (!profileDoc.exists) {
        throw new Error("User profile not found");
      }

      return {
        token: await userCredential.user.getIdToken(),
        user: normalizeDoc(profileDoc)
      };
    }

    const user = findLocalUser(email, password);
    if (!user) {
      throw new Error("Invalid email or password");
    }

    return {
      token: `local-token-${btoa(user.email)}`,
      user
    };
  };

  const logout = async () => {
    if (useFirebase) {
      const auth = getAuth();
      if (auth) {
        try {
          await auth.signOut();
        } catch (error) {
          console.warn("Firebase sign out failed", error);
        }
      }
    }
    Storage.clear();
  };

  const createQuery = async (queryData) => {
    const user = ensureLoggedIn();
    const newQuery = {
      id: `query-${Date.now()}`,
      menteeId: user.id,
      menteeName: user.name,
      menteeEmployeeId: user.employeeId,
      questionTitle: queryData.questionTitle,
      category: queryData.category,
      complexity: queryData.complexity,
      meetingType: queryData.meetingType,
      preferredSlot: queryData.preferredSlot,
      detailedQuery: queryData.detailedQuery,
      status: "OPEN",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (useFirebase) {
      const queryRef = getFirestore().collection("queries").doc();
      newQuery.id = queryRef.id;
      await queryRef.set(newQuery);
      return { data: newQuery };
    }

    const queries = getLocalQueries();
    queries.unshift(newQuery);
    saveLocalQueries(queries);
    return { data: newQuery };
  };

  const getMyQueries = async () => {
    const user = ensureLoggedIn();
    if (useFirebase) {
      const snapshot = await getFirestore()
        .collection("queries")
        .where("menteeId", "==", user.id)
        .orderBy("createdAt", "desc")
        .get();
      return { data: snapshot.docs.map(normalizeDoc) };
    }

    const queries = getLocalQueries().filter(query => query.menteeId === user.id);
    return { data: queries.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) };
  };

  const getMentorQueries = async () => {
    const user = ensureLoggedIn();
    if (useFirebase) {
      const snapshot = await getFirestore()
        .collection("queries")
        .where("assignedMentorId", "==", user.id)
        .orderBy("createdAt", "desc")
        .get();
      return { data: snapshot.docs.map(normalizeDoc) };
    }

    const queries = getLocalQueries().filter(query => query.assignedMentorId === user.id);
    return { data: queries.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) };
  };

  const getAllQueries = async () => {
    if (useFirebase) {
      const snapshot = await getFirestore()
        .collection("queries")
        .orderBy("createdAt", "desc")
        .get();
      return { data: snapshot.docs.map(normalizeDoc) };
    }

    const queries = getLocalQueries();
    return { data: queries.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) };
  };

  const assignQueryToMentor = async (queryId, menteeId, mentorId, mentorName) => {
    const updateData = {
      assignedMentorId: mentorId,
      assignedMentorName: mentorName || getMentorById(mentorId).name,
      status: "ASSIGNED",
      updatedAt: new Date().toISOString()
    };

    if (useFirebase) {
      const queryRef = getFirestore().collection("queries").doc(queryId);
      await queryRef.update(updateData);
      const queryDoc = await queryRef.get();
      return { data: normalizeDoc(queryDoc) };
    }

    const queries = getLocalQueries();
    const index = queries.findIndex(query => query.id === queryId);
    if (index === -1) {
      throw new Error("Query not found");
    }

    queries[index] = { ...queries[index], ...updateData };
    saveLocalQueries(queries);
    return { data: queries[index] };
  };

  const addPreferredSlots = async (queryId, menteeId, slots) => {
    const updateData = {
      mentorPreferredSlots: slots,
      status: "SLOTS_SHARED",
      updatedAt: new Date().toISOString()
    };

    if (useFirebase) {
      const queryRef = getFirestore().collection("queries").doc(queryId);
      await queryRef.update(updateData);
      const queryDoc = await queryRef.get();
      return { data: normalizeDoc(queryDoc) };
    }

    const queries = getLocalQueries();
    const index = queries.findIndex(query => query.id === queryId);
    if (index === -1) {
      throw new Error("Query not found");
    }

    queries[index] = { ...queries[index], ...updateData };
    saveLocalQueries(queries);
    return { data: queries[index] };
  };

  const addResolution = async (queryId, menteeId, resolution) => {
    const updateData = {
      resolution,
      resolutionProvidedAt: new Date().toISOString(),
      status: "RESOLVED",
      updatedAt: new Date().toISOString()
    };

    if (useFirebase) {
      const queryRef = getFirestore().collection("queries").doc(queryId);
      await queryRef.update(updateData);
      const queryDoc = await queryRef.get();
      return { data: normalizeDoc(queryDoc) };
    }

    const queries = getLocalQueries();
    const index = queries.findIndex(query => query.id === queryId);
    if (index === -1) {
      throw new Error("Query not found");
    }

    queries[index] = { ...queries[index], ...updateData };
    saveLocalQueries(queries);
    return { data: queries[index] };
  };

  const closeQuery = async (queryId, menteeId, closingComments, closedBy) => {
    const updateData = {
      status: "CLOSED",
      closedAt: new Date().toISOString(),
      closedBy,
      closingComments,
      updatedAt: new Date().toISOString()
    };

    if (useFirebase) {
      const queryRef = getFirestore().collection("queries").doc(queryId);
      await queryRef.update(updateData);
      const queryDoc = await queryRef.get();
      return { data: normalizeDoc(queryDoc) };
    }

    const queries = getLocalQueries();
    const index = queries.findIndex(query => query.id === queryId);
    if (index === -1) {
      throw new Error("Query not found");
    }

    queries[index] = { ...queries[index], ...updateData };
    saveLocalQueries(queries);
    return { data: queries[index] };
  };

  const getAnalytics = async () => {
    if (useFirebase) {
      const snapshot = await getFirestore().collection("queries").get();
      const analyticsMap = new Map();

      snapshot.docs.forEach((doc) => {
        const data = doc.data();
        const complexity = data.complexity || "UNKNOWN";
        const status = data.status || "UNKNOWN";
        const key = `${complexity}||${status}`;
        analyticsMap.set(key, (analyticsMap.get(key) || 0) + 1);
      });

      return {
        data: Array.from(analyticsMap.entries()).map(([key, count]) => {
          const [complexity, status] = key.split("||");
          return { complexity, status, count };
        })
      };
    }

    const queries = getLocalQueries();
    const analyticsMap = new Map();

    queries.forEach((data) => {
      const complexity = data.complexity || "UNKNOWN";
      const status = data.status || "UNKNOWN";
      const key = `${complexity}||${status}`;
      analyticsMap.set(key, (analyticsMap.get(key) || 0) + 1);
    });

    return {
      data: Array.from(analyticsMap.entries()).map(([key, count]) => {
        const [complexity, status] = key.split("||");
        return { complexity, status, count };
      })
    };
  };

  const getUsersByRole = async (role) => {
    if (useFirebase) {
      const snapshot = await getFirestore()
        .collection("users")
        .where("role", "==", role)
        .get();

      return { data: snapshot.docs.map(normalizeDoc) };
    }

    const users = getLocalUsers().filter(user => user.role === role);
    return { data: users };
  };

  return {
    register,
    login,
    logout,
    createQuery,
    getMyQueries,
    getMentorQueries,
    getAllQueries,
    assignQueryToMentor,
    addPreferredSlots,
    addResolution,
    closeQuery,
    getAnalytics,
    getUsersByRole
  };
})();

window.FirebaseAPI = FirebaseSDK;
window.API = FirebaseSDK;

// ============================================
// AUTHENTICATION PAGES
// ============================================

const AuthPages = {
  renderLoginPage: () => {
    return `
      <div class="auth-container">
        <div class="auth-form">
          <h1>🔐 Login</h1>
          <p>Query Management System</p>
          
          <form id="loginForm">
            <div class="form-group">
              <label for="email">Email Address</label>
              <input type="email" id="email" name="email" required placeholder="Enter your email">
            </div>
            
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" id="password" name="password" required placeholder="Enter your password">
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">Login</button>
          </form>
          
          <div class="auth-link">
            Don't have an account? <a href="#" onclick="app.showRegisterPage()">Register here</a>
          </div>
        </div>
      </div>
    `;
  },

  renderRegisterPage: () => {
    return `
      <div class="auth-container">
        <div class="auth-form">
          <h1>✍️ Register</h1>
          <p>Create your account</p>
          
          <form id="registerForm">
            <div class="form-group">
              <label for="name">Full Name</label>
              <input type="text" id="name" name="name" required placeholder="Enter your full name">
            </div>
            
            <div class="form-group">
              <label for="email">Email Address</label>
              <input type="email" id="email" name="email" required placeholder="Enter your email">
            </div>
            
            <div class="form-group">
              <label for="employeeId">Employee ID</label>
              <input type="text" id="employeeId" name="employeeId" required placeholder="Enter your employee ID">
            </div>
            
            <div class="form-group">
              <label for="department">Department</label>
              <input type="text" id="department" name="department" required placeholder="Enter your department">
            </div>
            
            <div class="form-group">
              <label for="role">Role</label>
              <select id="role" name="role" required>
                <option value="">Select your role</option>
                <option value="MENTEE">Mentee</option>
                <option value="MENTOR">Mentor</option>
                <option value="ADMIN">Admin</option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" id="password" name="password" required placeholder="Enter a password (min 6 characters)">
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">Register</button>
          </form>
          
          <div class="auth-link">
            Already have an account? <a href="#" onclick="app.showLoginPage()">Login here</a>
          </div>
        </div>
      </div>
    `;
  },

  handleLoginSubmit: async (e) => {
    e.preventDefault();
    
    const formData = FormHelper.getFormData("loginForm");
    
    if (!Validation.email(formData.email)) {
      Notification.error("Please enter a valid email");
      return;
    }
    
    if (!Validation.password(formData.password)) {
      Notification.error("Password must be at least 6 characters");
      return;
    }

    try {
      FormHelper.disableForm("loginForm", true);
      
      const response = await API.login(formData.email, formData.password);
      
      Storage.setToken(response.token);
      Storage.setUser(response.user);
      
      Notification.success("Login successful!");
      
      setTimeout(() => {
        app.loadDashboard(response.user.role);
      }, 500);
    } catch (error) {
      handleError(error);
      FormHelper.disableForm("loginForm", false);
    }
  },

  handleRegisterSubmit: async (e) => {
    e.preventDefault();
    
    const formData = FormHelper.getFormData("registerForm");
    
    const errors = Validation.validateForm(formData);
    if (Object.keys(errors).length > 0) {
      Notification.error("Please fill in all required fields");
      return;
    }
    
    if (!Validation.email(formData.email)) {
      Notification.error("Please enter a valid email");
      return;
    }
    
    if (!Validation.password(formData.password)) {
      Notification.error("Password must be at least 6 characters");
      return;
    }

    try {
      FormHelper.disableForm("registerForm", true);
      
      const response = await API.register(formData);
      
      Storage.setToken(response.token);
      Storage.setUser(response.user);
      
      Notification.success("Registration successful!");
      
      setTimeout(() => {
        app.loadDashboard(response.user.role);
      }, 500);
    } catch (error) {
      handleError(error);
      FormHelper.disableForm("registerForm", false);
    }
  }
};

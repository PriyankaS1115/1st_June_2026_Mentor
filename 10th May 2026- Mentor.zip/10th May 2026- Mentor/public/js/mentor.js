// ============================================
// MENTOR PAGES & FUNCTIONALITY
// ============================================

const MentorPages = {
  renderDashboard: () => {
    return `
      <div class="container">
        <div class="card">
          <div class="card-header">
            <h2>👨‍🏫 Mentor Dashboard</h2>
            <p>Manage assigned queries and provide resolutions</p>
          </div>
          
          <div id="analyticsContainer" class="grid grid-3 mb-4">
            <div class="loading"></div>
          </div>
          
          <div id="queriesContainer">
            <div class="text-center">
              <div class="loading"></div>
              <p>Loading assigned queries...</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Add Slots Modal -->
      <div id="addSlotsModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Share Preferred Meeting Slots</h2>
            <button class="modal-close" onclick="ModalHelper.close('addSlotsModal')">×</button>
          </div>
          
          <div class="modal-body">
            <form id="addSlotsForm">
              <div class="form-group">
                <label>Select Preferred Slots</label>
                <div id="slotsCheckboxes"></div>
              </div>
              <div class="form-group">
                <label for="additionalSlot">Add Custom Slot (Optional)</label>
                <input type="datetime-local" id="additionalSlot" name="additionalSlot">
              </div>
            </form>
          </div>
          
          <div class="modal-footer">
            <button class="btn btn-secondary" onclick="ModalHelper.close('addSlotsModal')">Cancel</button>
            <button class="btn btn-primary" onclick="MentorPages.handleAddSlots()">Share Slots</button>
          </div>
        </div>
      </div>

      <!-- Add Resolution Modal -->
      <div id="addResolutionModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Provide Resolution</h2>
            <button class="modal-close" onclick="ModalHelper.close('addResolutionModal')">×</button>
          </div>
          
          <div class="modal-body">
            <form id="addResolutionForm">
              <div class="form-group">
                <label for="resolution">Resolution/Solution</label>
                <textarea id="resolution" name="resolution" required placeholder="Provide detailed resolution for the query..."></textarea>
              </div>
            </form>
          </div>
          
          <div class="modal-footer">
            <button class="btn btn-secondary" onclick="ModalHelper.close('addResolutionModal')">Cancel</button>
            <button class="btn btn-success" onclick="MentorPages.handleAddResolution()">Submit Resolution</button>
          </div>
        </div>
      </div>

      <!-- Close Query Modal -->
      <div id="closeQueryModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Close Query</h2>
            <button class="modal-close" onclick="ModalHelper.close('closeQueryModal')">×</button>
          </div>
          
          <div class="modal-body">
            <form id="closeQueryForm">
              <div class="form-group">
                <label for="closingComments">Closing Comments</label>
                <textarea id="closingComments" name="closingComments" required placeholder="Add any closing comments..."></textarea>
              </div>
            </form>
          </div>
          
          <div class="modal-footer">
            <button class="btn btn-secondary" onclick="ModalHelper.close('closeQueryModal')">Cancel</button>
            <button class="btn btn-danger" onclick="MentorPages.handleCloseQuery()">Close Query</button>
          </div>
        </div>
      </div>
    `;
  },

  loadAnalytics: async () => {
    try {
      const response = await API.getAnalytics();
      const container = document.getElementById("analyticsContainer");
      
      if (!response.data || response.data.length === 0) {
        container.innerHTML = '<p class="text-muted">No analytics data available</p>';
        return;
      }

      let html = '';
      const complexityCount = {};
      
      response.data.forEach(item => {
        const key = item.complexity || 'unknown';
        complexityCount[key] = (complexityCount[key] || 0) + item.count;
      });

      for (const [complexity, count] of Object.entries(complexityCount)) {
        const badge = {
          'low': 'success',
          'medium': 'warning',
          'high': 'danger'
        }[complexity] || 'primary';
        
        html += RenderHelper.renderStatCard(
          `${complexity.toUpperCase()} Complexity`,
          count,
          `Queries`
        );
      }
      
      container.innerHTML = html;
    } catch (error) {
      console.error("Error loading analytics:", error);
    }
  },

  loadQueries: async () => {
    try {
      const response = await API.getAllQueries();
      const container = document.getElementById("queriesContainer");
      
      if (!response.data || response.data.length === 0) {
        container.innerHTML = `
          <div class="text-center mt-4">
            <p class="text-muted">No queries available yet.</p>
          </div>
        `;
        return;
      }

      let html = '';
      response.data.forEach(query => {
        const statusClass = {
          'OPEN': 'primary',
          'ASSIGNED': 'info',
          'SLOTS_SHARED': 'warning',
          'RESOLVED': 'success',
          'CLOSED': 'danger'
        }[query.status] || 'primary';

        const daysDiff = DateUtils.calculateDaysDiff(query.createdAt, new Date());

        html += `
          <div class="query-item">
            <div class="query-header">
              <div>
                <div class="query-title">${query.questionTitle}</div>
                <div class="query-meta">
                  <span>👤 ${query.menteeName}</span>
                  <span>📂 ${query.category}</span>
                  <span>⚙️ ${query.complexity}</span>
                  <span>👨‍🏫 ${query.assignedMentorName || 'Unassigned'}</span>
                  <span>⏱️ ${daysDiff} days</span>
                </div>
              </div>
              <div class="query-status">
                <span class="badge badge-${statusClass}">${query.status}</span>
              </div>
            </div>
            
            <p class="mb-2">${query.detailedQuery}</p>
            
            ${query.resolution ? `
              <div class="alert alert-success mb-2">
                <strong>✓ Resolution:</strong> ${query.resolution}
              </div>
            ` : ''}
            
            <div class="query-actions">
              ${query.status !== 'CLOSED' ? `
                ${query.status !== 'SLOTS_SHARED' ? `
                  <button class="btn btn-sm btn-warning" onclick="MentorPages.openAddSlotsModal('${query.id}', '${query.menteeId}')">
                    📅 Share Slots
                  </button>
                ` : ''}
                
                ${!query.resolution ? `
                  <button class="btn btn-sm btn-success" onclick="MentorPages.openAddResolutionModal('${query.id}', '${query.menteeId}')">
                    💡 Add Resolution
                  </button>
                ` : ''}
                
                <button class="btn btn-sm btn-danger" onclick="MentorPages.openCloseQueryModal('${query.id}', '${query.menteeId}')">
                  ✖ Close Query
                </button>
              ` : `
                <span class="badge badge-danger">Query Closed</span>
              `}
            </div>
          </div>
        `;
      });
      
      container.innerHTML = html;
    } catch (error) {
      handleError(error);
    }
  },

  openAddSlotsModal: (queryId, menteeId) => {
    window.currentQueryId = queryId;
    window.currentMenteeId = menteeId;
    
    const slots = [
      "Monday 10:00 AM - 11:00 AM",
      "Tuesday 2:00 PM - 3:00 PM",
      "Wednesday 10:00 AM - 11:00 AM",
      "Thursday 3:00 PM - 4:00 PM",
      "Friday 9:00 AM - 10:00 AM"
    ];
    
    let html = '';
    slots.forEach(slot => {
      html += `
        <div style="margin-bottom: 10px;">
          <input type="checkbox" name="slot" value="${slot}" id="slot_${slot}">
          <label for="slot_${slot}">${slot}</label>
        </div>
      `;
    });
    
    document.getElementById("slotsCheckboxes").innerHTML = html;
    ModalHelper.open("addSlotsModal");
  },

  handleAddSlots: async () => {
    const selectedSlots = Array.from(document.querySelectorAll('input[name="slot"]:checked'))
      .map(el => el.value);
    
    const additionalSlot = document.getElementById("additionalSlot").value;
    if (additionalSlot) {
      selectedSlots.push(additionalSlot);
    }

    if (selectedSlots.length === 0) {
      Notification.error("Please select at least one slot");
      return;
    }

    try {
      await API.addPreferredSlots(window.currentQueryId, window.currentMenteeId, selectedSlots);
      Notification.success("Slots shared successfully!");
      ModalHelper.close("addSlotsModal");
      MentorPages.loadQueries();
    } catch (error) {
      handleError(error);
    }
  },

  openAddResolutionModal: (queryId, menteeId) => {
    window.currentQueryId = queryId;
    window.currentMenteeId = menteeId;
    ModalHelper.open("addResolutionModal");
  },

  handleAddResolution: async () => {
    const formData = FormHelper.getFormData("addResolutionForm");
    
    if (!formData.resolution || formData.resolution.trim() === "") {
      Notification.error("Please provide a resolution");
      return;
    }

    try {
      await API.addResolution(window.currentQueryId, window.currentMenteeId, formData.resolution);
      Notification.success("Resolution added successfully!");
      ModalHelper.close("addResolutionModal");
      FormHelper.resetForm("addResolutionForm");
      MentorPages.loadQueries();
    } catch (error) {
      handleError(error);
    }
  },

  openCloseQueryModal: (queryId, menteeId) => {
    window.currentQueryId = queryId;
    window.currentMenteeId = menteeId;
    ModalHelper.open("closeQueryModal");
  },

  handleCloseQuery: async () => {
    const formData = FormHelper.getFormData("closeQueryForm");
    
    if (!formData.closingComments || formData.closingComments.trim() === "") {
      Notification.error("Please provide closing comments");
      return;
    }

    try {
      const user = Storage.getUser();
      await API.closeQuery(
        window.currentQueryId,
        window.currentMenteeId,
        formData.closingComments,
        user.name
      );
      
      Notification.success("Query closed successfully!");
      ModalHelper.close("closeQueryModal");
      FormHelper.resetForm("closeQueryForm");
      MentorPages.loadQueries();
    } catch (error) {
      handleError(error);
    }
  }
};

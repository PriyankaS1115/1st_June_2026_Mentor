// ============================================
// ADMIN PAGES & FUNCTIONALITY
// ============================================

const MENTOR_OPTIONS = [
  { id: "mentor1", name: "John Smith" },
  { id: "mentor2", name: "Sarah Johnson" },
  { id: "mentor3", name: "Mike Davis" },
  { id: "mentor4", name: "Emily Brown" }
];

const AdminPages = {
  renderDashboard: () => {
    return `
      <div class="container">
        <!-- Analytics Dashboard -->
        <div class="card">
          <div class="card-header">
            <h2>📊 Analytics Dashboard</h2>
            <p>Query analysis by complexity and status</p>
          </div>
          
          <div id="analyticsContainer" class="grid grid-4 mb-4">
            <div class="loading"></div>
          </div>
        </div>

        <!-- Queries Management -->
        <div class="card">
          <div class="card-header">
            <h2>⚙️ Query Management</h2>
            <p>Manage all queries and assignments</p>
          </div>
          
          <div class="btn-group mb-3">
            <button class="btn btn-primary" onclick="AdminPages.filterQueries('all')">All Queries</button>
            <button class="btn btn-secondary" onclick="AdminPages.filterQueries('open')">Open</button>
            <button class="btn btn-warning" onclick="AdminPages.filterQueries('assigned')">Assigned</button>
            <button class="btn btn-success" onclick="AdminPages.filterQueries('resolved')">Resolved</button>
            <button class="btn btn-danger" onclick="AdminPages.filterQueries('closed')">Closed</button>
            <button class="btn btn-success" onclick="AdminPages.exportQueries()">Download Excel</button>
          </div>
          
          <div id="queriesContainer">
            <div class="text-center">
              <div class="loading"></div>
              <p>Loading queries...</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Assign Mentor Modal -->
      <div id="assignMentorModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Assign Mentor to Query</h2>
            <button class="modal-close" onclick="ModalHelper.close('assignMentorModal')">×</button>
          </div>
          
          <div class="modal-body">
            <form id="assignMentorForm">
              <div class="form-group">
                <label for="mentorSelect">Select Mentor</label>
                <select id="mentorSelect" name="mentorSelect" required>
                  <option value="">Loading mentors...</option>
                </select>
              </div>
            </form>
          </div>
          
          <div class="modal-footer">
            <button class="btn btn-secondary" onclick="ModalHelper.close('assignMentorModal')">Cancel</button>
            <button class="btn btn-primary" onclick="AdminPages.handleAssignMentor()">Assign</button>
          </div>
        </div>
      </div>

      <!-- Close Query Modal -->
      <div id="adminCloseQueryModal" class="modal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Close Query</h2>
            <button class="modal-close" onclick="ModalHelper.close('adminCloseQueryModal')">×</button>
          </div>
          
          <div class="modal-body">
            <form id="adminCloseQueryForm">
              <div class="form-group">
                <label for="adminClosingComments">Closing Comments</label>
                <textarea id="adminClosingComments" name="adminClosingComments" required></textarea>
              </div>
            </form>
          </div>
          
          <div class="modal-footer">
            <button class="btn btn-secondary" onclick="ModalHelper.close('adminCloseQueryModal')">Cancel</button>
            <button class="btn btn-danger" onclick="AdminPages.handleAdminCloseQuery()">Close Query</button>
          </div>
        </div>
      </div>
    `;
  },

  loadAnalytics: async () => {
    try {
      const response = await API.getAnalytics();
      const container = document.getElementById("analyticsContainer");
      
      let html = '';
      
      if (response.data && response.data.length > 0) {
        const grouped = {};
        
        response.data.forEach(item => {
          const status = item.status || 'UNKNOWN';
          if (!grouped[status]) {
            grouped[status] = {};
          }
          grouped[status][item.complexity || 'unknown'] = item.count || 0;
        });

        for (const [status, complexities] of Object.entries(grouped)) {
          const total = Object.values(complexities).reduce((a, b) => a + b, 0);
          const badgeClass = {
            'OPEN': 'primary',
            'ASSIGNED': 'info',
            'RESOLVED': 'success',
            'CLOSED': 'danger'
          }[status] || 'secondary';
          
          html += `
            <div class="stats-card" style="background: linear-gradient(135deg, var(--secondary-color), #2980b9);">
              <h3>${status}</h3>
              <div class="stat-value">${total}</div>
              <div class="stat-change">Queries</div>
            </div>
          `;
        }
      }
      
      container.innerHTML = html || '<p class="text-muted">No analytics data</p>';
    } catch (error) {
      console.error("Error loading analytics:", error);
    }
  },

  loadQueries: async () => {
    try {
      const response = await API.getAllQueries();
      const container = document.getElementById("queriesContainer");
      
      window.allQueries = response.data || [];
      
      if (!window.allQueries.length) {
        container.innerHTML = '<p class="text-muted">No queries available</p>';
        return;
      }

      AdminPages.renderQueries(window.allQueries);
    } catch (error) {
      handleError(error);
    }
  },

  renderQueries: (queries) => {
    const container = document.getElementById("queriesContainer");
    
    if (!queries || queries.length === 0) {
      container.innerHTML = '<p class="text-muted">No queries found</p>';
      return;
    }

    let html = '';
    queries.forEach(query => {
      const statusClass = {
        'OPEN': 'primary',
        'ASSIGNED': 'info',
        'SLOTS_SHARED': 'warning',
        'RESOLVED': 'success',
        'CLOSED': 'danger'
      }[query.status] || 'primary';

      const daysDiff = DateUtils.calculateDaysDiff(query.createdAt, query.closedAt || new Date());

      html += `
        <div class="query-item">
          <div class="query-header">
            <div>
              <div class="query-title">${query.questionTitle}</div>
              <div class="query-meta">
                <span>👤 ${query.menteeName}</span>
                <span>📂 ${query.category}</span>
                <span>⚙️ ${query.complexity}</span>
                <span>⏱️ ${daysDiff} days</span>
                <span>📅 ${DateUtils.format(query.createdAt)}</span>
              </div>
            </div>
            <div class="query-status">
              <span class="badge badge-${statusClass}">${query.status}</span>
            </div>
          </div>
          
          <p class="mb-2">${query.detailedQuery}</p>
          
          ${query.resolution ? `
            <div class="alert alert-success mb-2">
              <strong>✓ Resolution:</strong> ${query.resolution}
            </div>
          ` : ''}
          
          <div class="query-actions">
            ${query.status === 'OPEN' ? `
              <button class="btn btn-sm btn-primary" onclick="AdminPages.openAssignMentorModal('${query.id}', '${query.menteeId}')">
                👨‍🏫 Assign Mentor
              </button>
            ` : ''}
            
            ${query.status !== 'CLOSED' ? `
              <button class="btn btn-sm btn-danger" onclick="AdminPages.openAdminCloseQueryModal('${query.id}', '${query.menteeId}')">
                ✖ Close
              </button>
            ` : ''}
          </div>
        </div>
      `;
    });
    
    container.innerHTML = html;
  },

  filterQueries: (status) => {
    if (!window.allQueries) return;
    
    let filtered = window.allQueries;
    
    if (status !== 'all') {
      const statusMap = {
        'open': 'OPEN',
        'assigned': 'ASSIGNED',
        'resolved': 'RESOLVED',
        'closed': 'CLOSED'
      };
      
      filtered = window.allQueries.filter(q => q.status === statusMap[status]);
    }
    
    AdminPages.renderQueries(filtered);
  },

  openAssignMentorModal: (queryId, menteeId) => {
    window.currentQueryId = queryId;
    window.currentMenteeId = menteeId;
    
    const mentorSelect = document.getElementById("mentorSelect");
    mentorSelect.innerHTML = `
      <option value="">Select a mentor</option>
      ${MENTOR_OPTIONS.map(mentor => `
        <option value="${mentor.id}">${mentor.name} - ${mentor.expertise}</option>
      `).join("")}
    `;
    
    ModalHelper.open("assignMentorModal");
  },

  handleAssignMentor: async () => {
    const mentorId = document.getElementById("mentorSelect").value;
    const mentor = MENTOR_OPTIONS.find(item => item.id === mentorId);
    
    if (!mentorId) {
      Notification.error("Please select a mentor");
      return;
    }

    try {
      await API.assignQueryToMentor(
        window.currentQueryId,
        window.currentMenteeId,
        mentorId,
        mentor?.name || mentorId
      );
      
      Notification.success("Mentor assigned successfully!");
      ModalHelper.close("assignMentorModal");
      AdminPages.loadQueries();
    } catch (error) {
      handleError(error);
    }
  },

  openAdminCloseQueryModal: (queryId, menteeId) => {
    window.currentQueryId = queryId;
    window.currentMenteeId = menteeId;
    ModalHelper.open("adminCloseQueryModal");
  },

  handleAdminCloseQuery: async () => {
    const formData = FormHelper.getFormData("adminCloseQueryForm");
    
    if (!formData.adminClosingComments || formData.adminClosingComments.trim() === "") {
      Notification.error("Please provide closing comments");
      return;
    }

    try {
      const user = Storage.getUser();
      await API.closeQuery(
        window.currentQueryId,
        window.currentMenteeId,
        formData.adminClosingComments,
        user.name
      );
      
      Notification.success("Query closed successfully!");
      ModalHelper.close("adminCloseQueryModal");
      FormHelper.resetForm("adminCloseQueryForm");
      AdminPages.loadQueries();
    } catch (error) {
      handleError(error);
    }
  },

exportQueries: async () => {
    if (!window.allQueries || window.allQueries.length === 0) {
      const response = await API.getAllQueries();
      window.allQueries = response.data || [];
    }

    if (!window.allQueries || window.allQueries.length === 0) {
      Notification.error("No queries available to export");
      return;
    }

    const headers = [
      "Query ID",
      "Question Title",
      "Category",
      "Complexity",
      "Meeting Type",
      "Preferred Slot",
      "Status",
      "Assigned Mentor",
      "Mentee Name",
      "Mentee Employee ID",
      "Resolution",
      "Closed By",
      "Closing Comments",
      "Created At",
      "Updated At"
    ];

    const escapeCsv = (value) => {
      if (value === undefined || value === null) return "";
      const normalized = String(value).replace(/"/g, '""');
      return `"${normalized}"`;
    };

    const rows = window.allQueries.map(query => [
      query.id,
      query.questionTitle,
      query.category,
      query.complexity,
      query.meetingType,
      query.preferredSlot,
      query.status,
      query.assignedMentorName || query.assignedMentorId || "Unassigned",
      query.menteeName,
      query.menteeEmployeeId,
      query.resolution || "",
      query.closedBy || "",
      query.closingComments || "",
      query.createdAt,
      query.updatedAt
    ]);

    const csvContent = [headers.map(escapeCsv).join(","), ...rows.map(row => row.map(escapeCsv).join(","))].join("\r\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `query-export-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
};

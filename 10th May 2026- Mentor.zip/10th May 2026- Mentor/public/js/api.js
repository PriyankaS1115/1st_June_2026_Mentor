// ============================================
// API REQUEST HANDLER - AZURE FUNCTIONS
// ============================================

// For local development with the Express backend: http://localhost:3000/api
// For production: set REACT_APP_API_URL or use a relative path
const API_BASE_URL = process.env.REACT_APP_API_URL || "/api";

class API {
  static async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const headers = {
      "Content-Type": "application/json",
      ...options.headers
    };

    const token = Storage.getToken();
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(url, {
        method: options.method || "GET",
        headers,
        body: options.body ? JSON.stringify(options.body) : undefined
      });

      const data = await response.json();

      if (!response.ok) {
        throw {
          status: response.status,
          message: data.message || "An error occurred"
        };
      }

      return data;
    } catch (error) {
      console.error("API Error:", error);
      throw error;
    }
  }

  // Auth endpoints
  static async register(userData) {
    return this.request("/auth/register", {
      method: "POST",
      body: userData
    });
  }

  static async login(email, password) {
    return this.request("/auth/login", {
      method: "POST",
      body: { email, password }
    });
  }

  static async getCurrentUser() {
    return this.request("/auth/me");
  }

  // Query endpoints
  static async createQuery(queryData) {
    return this.request("/queries/create", {
      method: "POST",
      body: queryData
    });
  }

  static async getMyQueries() {
    return this.request("/queries/my-queries");
  }

  static async getMentorQueries() {
    return this.request("/queries/mentor-queries");
  }

  static async getAllQueries() {
    return this.request("/queries/all-queries");
  }

  static async assignQueryToMentor(queryId, menteeId, mentorId) {
    return this.request("/queries/assign-mentor", {
      method: "POST",
      body: { queryId, menteeId, mentorId }
    });
  }

  static async addPreferredSlots(queryId, menteeId, slots) {
    return this.request("/queries/add-slots", {
      method: "POST",
      body: { queryId, menteeId, slots }
    });
  }

  static async addResolution(queryId, menteeId, resolution) {
    return this.request("/queries/add-resolution", {
      method: "POST",
      body: { queryId, menteeId, resolution }
    });
  }

  static async closeQuery(queryId, menteeId, closingComments, closedBy) {
    return this.request("/queries/close", {
      method: "POST",
      body: { queryId, menteeId, closingComments, closedBy }
    });
  }

  static async getAnalytics() {
    return this.request("/queries/analytics");
  }
}

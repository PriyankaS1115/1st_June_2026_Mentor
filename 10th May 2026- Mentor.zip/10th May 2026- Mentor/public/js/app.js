// ============================================
// MAIN APPLICATION
// ============================================

const app = {
  currentUser: null,
  currentPage: null,

  init: async () => {
    // Check if user is already logged in
    const token = Storage.getToken();
    const user = Storage.getUser();

    if (token && user) {
      app.currentUser = user;
      app.loadDashboard(user.role);
    } else {
      app.showLoginPage();
    }

    // Setup event listeners for modals
    document.addEventListener("click", (e) => {
      if (e.target.classList.contains("modal")) {
        e.target.classList.remove("show");
      }
    });
  },

  showLoginPage: () => {
    const mainContent = document.getElementById("main-content");
    mainContent.innerHTML = AuthPages.renderLoginPage();
    
    const navbar = document.getElementById("navbar");
    navbar.innerHTML = `
      <div class="navbar-brand">Query Management System</div>
    `;
    
    app.currentPage = "login";

    // Attach form submission handler
    document.getElementById("loginForm").addEventListener("submit", AuthPages.handleLoginSubmit);
  },

  showRegisterPage: () => {
    const mainContent = document.getElementById("main-content");
    mainContent.innerHTML = AuthPages.renderRegisterPage();
    
    const navbar = document.getElementById("navbar");
    navbar.innerHTML = `
      <div class="navbar-brand">Query Management System</div>
    `;
    
    app.currentPage = "register";

    // Attach form submission handler
    document.getElementById("registerForm").addEventListener("submit", AuthPages.handleRegisterSubmit);
  },

  loadDashboard: (role) => {
    app.renderNavbar(role);
    
    const mainContent = document.getElementById("main-content");
    
    if (role === "MENTEE") {
      mainContent.innerHTML = MenteePages.renderDashboard();
      MenteePages.loadQueries();
      
      // Attach event listener for create query form
      setTimeout(() => {
        const form = document.getElementById("createQueryForm");
        if (form) {
          form.addEventListener("submit", (e) => {
            e.preventDefault();
            MenteePages.handleCreateQuery();
          });
        }
      }, 100);
    } else if (role === "MENTOR") {
      mainContent.innerHTML = MentorPages.renderDashboard();
      MentorPages.loadAnalytics();
      MentorPages.loadQueries();
    } else if (role === "ADMIN") {
      mainContent.innerHTML = AdminPages.renderDashboard();
      AdminPages.loadAnalytics();
      AdminPages.loadQueries();
    }
    
    app.currentPage = role.toLowerCase();
  },

  renderNavbar: (role) => {
    const navbar = document.getElementById("navbar");
    const user = Storage.getUser();
    
    const menuItems = {
      MENTEE: [
        { label: "Dashboard", onclick: "app.reloadDashboard()" }
      ],
      MENTOR: [
        { label: "Dashboard", onclick: "app.reloadDashboard()" },
        { label: "My Queries", onclick: "MentorPages.loadQueries()" }
      ],
      ADMIN: [
        { label: "Dashboard", onclick: "app.reloadDashboard()" },
        { label: "Query Management", onclick: "AdminPages.loadQueries()" }
      ]
    };

    let menuHTML = "";
    if (menuItems[role]) {
      menuHTML = menuItems[role].map(item => `
        <li><a href="#" onclick="${item.onclick}">${item.label}</a></li>
      `).join("");
    }

    navbar.innerHTML = `
      <div class="navbar-brand">⚡ Query Management System</div>
      <ul class="navbar-menu">
        ${menuHTML}
      </ul>
      <div class="user-info">
        <span>${user.name}</span>
        <div class="user-avatar">${user.name.charAt(0).toUpperCase()}</div>
        <button class="logout-btn" onclick="app.logout()">Logout</button>
      </div>
    `;
  },

  reloadDashboard: () => {
    const user = Storage.getUser();
    app.loadDashboard(user.role);
  },

  logout: async () => {
    try {
      await API.logout();
    } catch (error) {
      console.warn("Logout failed", error);
    }

    Storage.clear();
    Notification.success("Logged out successfully!");
    setTimeout(() => {
      app.showLoginPage();
    }, 1000);
  }
};

// Initialize application when DOM is ready
document.addEventListener("DOMContentLoaded", app.init);

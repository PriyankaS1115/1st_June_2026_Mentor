// Replace these values with your Firebase Web app configuration.
// You can find them in the Firebase console under Project Settings > General.
const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "mentor-mentee-3e220.firebaseapp.com",
  projectId: "mentor-mentee-3e220",
  storageBucket: "mentor-mentee-3e220.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

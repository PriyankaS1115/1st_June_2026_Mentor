// ============================================
// UTILITY FUNCTIONS
// ============================================

// Local storage management
const Storage = {
  setUser: (user) => localStorage.setItem("user", JSON.stringify(user)),
  getUser: () => JSON.parse(localStorage.getItem("user")),
  setToken: (token) => localStorage.setItem("token", token),
  getToken: () => localStorage.getItem("token"),
  clear: () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
  }
};

// Date formatting
const DateUtils = {
  format: (date, format = "DD/MM/YYYY HH:mm") => {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");

    return format
      .replace("DD", day)
      .replace("MM", month)
      .replace("YYYY", year)
      .replace("HH:mm", `${hours}:${minutes}`);
  },

  calculateDaysDiff: (date1, date2) => {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    const diffTime = Math.abs(d2 - d1);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  },

  getRelativeTime: (date) => {
    const now = new Date();
    const past = new Date(date);
    const diffMs = now - past;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? "s" : ""} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
    return DateUtils.format(date);
  }
};

// Validation
const Validation = {
  email: (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
  
  password: (password) => password.length >= 6,
  
  required: (value) => value && value.trim().length > 0,
  
  validateForm: (data) => {
    const errors = {};
    
    for (const [key, value] of Object.entries(data)) {
      if (!Validation.required(value)) {
        errors[key] = `${key} is required`;
      }
    }
    
    return errors;
  }
};

// Notification system
const Notification = {
  show: (message, type = "info", duration = 3000) => {
    const notificationId = `notification-${Date.now()}`;
    const notificationHTML = `
      <div id="${notificationId}" class="alert alert-${type}">
        <strong>${type.toUpperCase()}:</strong> ${message}
      </div>
    `;
    
    const mainContent = document.getElementById("main-content");
    if (mainContent) {
      mainContent.insertAdjacentHTML("afterbegin", notificationHTML);
      
      if (duration) {
        setTimeout(() => {
          const el = document.getElementById(notificationId);
          if (el) el.remove();
        }, duration);
      }
    }
  },

  success: (message, duration = 3000) => Notification.show(message, "success", duration),
  error: (message, duration = 3000) => Notification.show(message, "danger", duration),
  warning: (message, duration = 3000) => Notification.show(message, "warning", duration),
  info: (message, duration = 3000) => Notification.show(message, "info", duration)
};

// Form helper
const FormHelper = {
  getFormData: (formId) => {
    const form = document.getElementById(formId);
    if (!form) return null;
    
    const formData = new FormData(form);
    const data = {};
    
    for (const [key, value] of formData.entries()) {
      data[key] = value;
    }
    
    return data;
  },

  resetForm: (formId) => {
    const form = document.getElementById(formId);
    if (form) form.reset();
  },

  disableForm: (formId, disabled = true) => {
    const form = document.getElementById(formId);
    if (!form) return;
    
    const inputs = form.querySelectorAll("input, textarea, select, button");
    inputs.forEach(input => {
      input.disabled = disabled;
    });
  },

  showError: (formId, fieldName, errorMessage) => {
    const field = document.querySelector(`#${formId} [name="${fieldName}"]`);
    if (!field) return;
    
    field.classList.add("error");
    const errorDiv = document.createElement("div");
    errorDiv.className = "error-message";
    errorDiv.textContent = errorMessage;
    field.parentNode.appendChild(errorDiv);
  }
};

// Modal helper
const ModalHelper = {
  open: (modalId) => {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add("show");
  },

  close: (modalId) => {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove("show");
  },

  closeAll: () => {
    document.querySelectorAll(".modal.show").forEach(modal => {
      modal.classList.remove("show");
    });
  }
};

// Render helpers
const RenderHelper = {
  renderQueryItem: (query) => {
    const statusBadgeClass = {
      "OPEN": "badge-primary",
      "ASSIGNED": "badge-info",
      "SLOTS_SHARED": "badge-warning",
      "RESOLVED": "badge-success",
      "CLOSED": "badge-danger"
    };

    const complexityBadgeClass = {
      "low": "badge-success",
      "medium": "badge-warning",
      "high": "badge-danger"
    };

    return `
      <div class="query-item">
        <div class="query-header">
          <div>
            <div class="query-title">${query.questionTitle || "Untitled Query"}</div>
            <div class="query-meta">
              <span>📝 ${query.category || "N/A"}</span>
              <span>👤 ${query.menteeName || "N/A"}</span>
              <span>📅 ${DateUtils.format(query.createdAt)}</span>
            </div>
          </div>
          <div class="query-status">
            <span class="badge ${statusBadgeClass[query.status] || 'badge-primary'}">${query.status || "UNKNOWN"}</span>
            <span class="badge ${complexityBadgeClass[query.complexity] || 'badge-primary'}">${query.complexity || "UNKNOWN"}</span>
          </div>
        </div>
        <p>${query.detailedQuery || "No description"}</p>
      </div>
    `;
  },

  renderStatCard: (title, value, change = null) => {
    return `
      <div class="stats-card">
        <h3>${title}</h3>
        <div class="stat-value">${value}</div>
        ${change ? `<div class="stat-change">${change}</div>` : ""}
      </div>
    `;
  }
};

// Error handling
const handleError = (error) => {
  console.error("Error:", error);
  
  if (error.response) {
    Notification.error(error.response.data?.message || "An error occurred");
  } else if (error.message) {
    Notification.error(error.message);
  } else {
    Notification.error("An unexpected error occurred");
  }
};

## 🌐 Azure Cosmos DB Setup Guide

This guide walks you through setting up Azure Cosmos DB for the Query Management System.

---

## 📋 Prerequisites

- ✅ Azure Account (Free or Paid)
- ✅ Azure Portal access
- ✅ Internet connection

---

## 🔧 Step-by-Step Setup

### Step 1: Create Resource Group (Optional but Recommended)

1. Go to [Azure Portal](https://portal.azure.com/)
2. Click **Resource groups** (search bar)
3. Click **+ Create**
4. Fill in:
   - **Resource group name**: `qms-resources`
   - **Region**: Select closest region
5. Click **Review + create** → **Create**

### Step 2: Create Cosmos DB Account

1. **Search for Cosmos DB**
   - In search bar, type "Azure Cosmos DB"
   - Click **Azure Cosmos DB**

2. **Click "+ Create"**
   - Select **Create single-region account** (simpler for testing)

3. **Fill in the form:**
   ```
   Project Details:
   - Subscription: Select your subscription
   - Resource Group: qms-resources (created above)
   
   Instance Details:
   - Account Name: qms-cosmos-db
   - Location: Select closest to you
   - Capacity Mode: Provisioned throughput
   - Apply Free Tier Discount: YES (if eligible)
   ```

4. **Click "Next: Global Distribution"**
   - Leave defaults
   - Click **Next: Backup Policy**

5. **Backup Policy**
   - Keep defaults
   - Click **Next: Networking**

6. **Networking**
   - Keep defaults for now (can restrict later)
   - Click **Review + create**

7. **Review & Create**
   - Check all settings
   - Click **Create**
   - Wait 5-10 minutes for deployment

### Step 3: Get Connection Details

1. **After deployment:**
   - Click **Go to resource**

2. **In left sidebar, click "Keys"**
   ```
   You'll see:
   - URI: https://your-account.documents.azure.com:443/
   - Primary Key: Your secret key
   ```

3. **Copy both values** (you'll need them next)

### Step 4: Create Database

1. **Click "Data Explorer"** in left sidebar

2. **Click "+ New Database"**
   - Database id: `query_management_db`
   - Throughput: 400 RU/s (free tier)
   - Click **OK**

3. **Create Collections:**

   **Collection 1: queries**
   - Database: query_management_db
   - Collection id: `queries`
   - Partition key: `/menteeId`
   - Throughput: 400 RU/s
   - Click **OK**

   **Collection 2: users**
   - Database: query_management_db
   - Collection id: `users`
   - Partition key: `/userId`
   - Throughput: 400 RU/s
   - Click **OK**

   **Collection 3: action_logs**
   - Database: query_management_db
   - Collection id: `action_logs`
   - Partition key: `/adminId`
   - Throughput: 400 RU/s
   - Click **OK**

   **Collection 4: mentors**
   - Database: query_management_db
   - Collection id: `mentors`
   - Partition key: `/mentorId`
   - Throughput: 400 RU/s
   - Click **OK**

   **Collection 5: mentees**
   - Database: query_management_db
   - Collection id: `mentees`
   - Partition key: `/menteeId`
   - Throughput: 400 RU/s
   - Click **OK**

### Step 5: Update Project Configuration

1. **Open `.env` file in VS Code**

2. **Replace with your values:**
   ```env
   COSMOS_DB_ENDPOINT=https://qms-cosmos-db.documents.azure.com:443/
   COSMOS_DB_KEY=YOUR_PRIMARY_KEY_HERE
   COSMOS_DB_NAME=query_management_db
   ```

3. **Save file** (Ctrl+S)

### Step 6: Test Connection

1. **Open terminal in VS Code** (Ctrl+`)

2. **Start server:**
   ```bash
   npm run dev
   ```

3. **You should see:**
   ```
   ✓ Database initialized successfully
   ✓ Server running on http://localhost:3000
   ```

If you see this, ✅ **You're connected!**

---

## 🔍 Verify Setup

### Check Collections in Azure Portal

1. Go to **Data Explorer** in Azure Portal
2. Expand `query_management_db`
3. You should see 5 collections:
   - ✅ queries
   - ✅ users
   - ✅ action_logs
   - ✅ mentors
   - ✅ mentees

### Test via VS Code Extension

1. **Install Azure Cosmos DB extension** (if not done)
2. **Click Azure icon** in left sidebar
3. **Sign in to Azure**
4. **Expand Cosmos DB**
5. **Find your account**
6. **You should see your database and collections**

---

## 💾 Backup & Security

### Enable Continuous Backup (Production)

1. Go to **Backup policy** in Azure Portal
2. Select **Continuous** (for 7/30 day retention)
3. This is good for production; free tier uses periodic backup

### Manage Access Keys

1. Go to **Keys** in Azure Portal
2. **Rotation** (Regenerate keys occasionally)
3. **Read-only keys** (for read-only access)

### Network Security

For production, restrict access:

1. Go to **Networking** in left sidebar
2. Select **Specific networks**
3. Add your IP addresses/VNets

---

## 📊 Monitor Usage

### Check Throughput & Costs

1. Go to **Metrics** in left sidebar
2. Monitor:
   - **RU Consumption** (Request Units)
   - **Storage** (GB used)
   - **Requests** (API calls)

### Optimize Costs

```
Cost Optimization Tips:
- Free Tier: 400 RU/s + 5GB storage
- Use provisioned throughput (not on-demand)
- Scale up only when needed
- Use partitioning wisely
```

---

## ⚠️ Common Issues

### Issue: "Authentication Error"

**Check:**
1. URI and Key are correct (no extra spaces)
2. Firewall allows your IP
3. Account is fully deployed (check notification bell)

**Solution:**
```env
# Copy directly from Azure Portal Keys page
COSMOS_DB_ENDPOINT=<exact-URI-from-portal>
COSMOS_DB_KEY=<exact-key-from-portal>
```

### Issue: "Database Not Found"

**Check:**
1. Database name matches: `query_management_db`
2. Collections are created (check in Data Explorer)
3. Partition keys are correct

### Issue: "Quota Exceeded"

**Solution:**
1. Scale up throughput (RU/s) in Azure Portal
2. Or wait for quota reset (daily)
3. Or use auto-scale (in production)

### Issue: "Request Rate Too Large"

**Cause:** Exceeded provisioned RU/s

**Solution:**
1. Go to Collections in Azure Portal
2. Click collection
3. Click **Scale**
4. Increase RU/s (e.g., 400 → 600)

---

## 🚀 Production Considerations

For production deployment:

1. **Use Azure App Service**
   - Deploy backend here
   - Connect to Cosmos DB

2. **Use Azure Static Web Apps**
   - Deploy frontend here
   - Lower costs for static hosting

3. **Enable Encryption**
   - Keys → Encryption (check if available)

4. **Implement Rate Limiting**
   - Prevent abuse
   - Monitor usage

5. **Regular Backups**
   - Enable continuous backup
   - Test restore process

6. **Monitor & Alerts**
   - Set up Azure Monitor alerts
   - Track RU consumption
   - Monitor errors

---

## 📚 Useful Azure Commands

### Install Azure CLI
```bash
# Download from https://docs.microsoft.com/cli/azure/install-azure-cli

# Login
az login

# List Cosmos DB accounts
az cosmosdb list

# Get connection string
az cosmosdb keys list --name qms-cosmos-db --resource-group qms-resources
```

### Check Quota
```bash
az cosmosdb throughput show \
  --resource-group qms-resources \
  --account-name qms-cosmos-db \
  --database-name query_management_db \
  --name queries
```

---

## 🔗 Useful Links

- [Azure Cosmos DB Free Tier](https://azure.microsoft.com/free/cosmos-db/)
- [Cosmos DB Pricing](https://azure.microsoft.com/pricing/details/cosmos-db/)
- [Partition Key Selection](https://docs.microsoft.com/azure/cosmos-db/partitioning-overview)
- [Query Best Practices](https://docs.microsoft.com/azure/cosmos-db/best-practice-cost)

---

## ✅ Checklist

- [ ] Azure account created
- [ ] Cosmos DB account created
- [ ] Database created: `query_management_db`
- [ ] 5 collections created with correct partition keys
- [ ] Connection details copied to `.env`
- [ ] Server tested and connected
- [ ] Collections visible in Data Explorer
- [ ] Ready to use!

---

**You're all set! Your Cosmos DB is ready for the Query Management System.** 🎉

Next: See [QUICK-START.md](./QUICK-START.md) for app setup

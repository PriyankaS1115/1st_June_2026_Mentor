const express = require("express");
const QueryController = require("../controllers/QueryController");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();

// Mentee routes
router.post(
  "/create",
  authenticate,
  authorize(["MENTEE"]),
  QueryController.createQuery
);

router.get(
  "/my-queries",
  authenticate,
  authorize(["MENTEE"]),
  QueryController.getMyQueries
);

// Mentor routes
router.get(
  "/mentor-queries",
  authenticate,
  authorize(["MENTOR"]),
  QueryController.getMentorQueries
);

router.post(
  "/add-slots",
  authenticate,
  authorize(["MENTOR"]),
  QueryController.addPreferredSlots
);

router.post(
  "/add-resolution",
  authenticate,
  authorize(["MENTOR"]),
  QueryController.addResolution
);

// Admin routes
router.get(
  "/all-queries",
  authenticate,
  authorize(["ADMIN"]),
  QueryController.getAllQueries
);

router.post(
  "/assign-mentor",
  authenticate,
  authorize(["ADMIN"]),
  QueryController.assignQueryToMentor
);

router.post(
  "/close",
  authenticate,
  authorize(["ADMIN", "MENTOR", "MENTEE"]),
  QueryController.closeQuery
);

router.get(
  "/analytics",
  authenticate,
  authorize(["ADMIN", "MENTOR"]),
  QueryController.getAnalytics
);

module.exports = router;

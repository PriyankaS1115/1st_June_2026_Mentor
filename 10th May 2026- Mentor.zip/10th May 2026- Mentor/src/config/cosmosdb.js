const admin = require("firebase-admin");
const path = require("path");

const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH;

function initializeDatabase() {
  if (!serviceAccountPath) {
    throw new Error(
      "Missing FIREBASE_SERVICE_ACCOUNT_PATH in environment. Set it in your .env file."
    );
  }

  if (!admin.apps.length) {
    const serviceAccount = require(path.resolve(process.cwd(), serviceAccountPath));

    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
  }

  const db = admin.firestore();
  console.log("✓ Firebase initialized successfully");
  return db;
}

function getFirestore() {
  if (!admin.apps.length) {
    initializeDatabase();
  }

  return admin.firestore();
}

module.exports = {
  initializeDatabase,
  getFirestore
};

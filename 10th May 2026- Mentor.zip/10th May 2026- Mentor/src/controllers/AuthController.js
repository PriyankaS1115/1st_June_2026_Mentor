const UserModel = require("../models/User");
const jwt = require("jsonwebtoken");

class AuthController {
  // Register user
  static async register(req, res) {
    try {
      const { email, password, name, employeeId, role, department } = req.body;

      // Check if user exists
      const existingUser = await UserModel.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Validate role
      if (!["MENTEE", "MENTOR", "ADMIN"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const userData = {
        email,
        password,
        name,
        employeeId,
        role,
        department
      };

      const newUser = await UserModel.createUser(userData);

      // Create token
      const token = jwt.sign(
        { userId: newUser.id, role: newUser.role },
        process.env.JWT_SECRET,
        { expiresIn: "24h" }
      );

      // Remove password from response
      const { password: _, ...userWithoutPassword } = newUser;

      res.status(201).json({
        message: "User registered successfully",
        token,
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Error registering user:", error);
      res.status(500).json({ message: "Error registering user", error: error.message });
    }
  }

  // Login user
  static async login(req, res) {
    try {
      const { email, password } = req.body;

      // Validate input
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password required" });
      }

      const user = await UserModel.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password
      const isPasswordValid = await UserModel.verifyPassword(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Create token
      const token = jwt.sign(
        { userId: user.id, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: "24h" }
      );

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;

      res.status(200).json({
        message: "Login successful",
        token,
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Error logging in:", error);
      res.status(500).json({ message: "Error logging in", error: error.message });
    }
  }

  // Get current user
  static async getCurrentUser(req, res) {
    try {
      const { password: _, ...userWithoutPassword } = req.user;
      res.status(200).json({
        message: "User fetched successfully",
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Error fetching user", error: error.message });
    }
  }
}

module.exports = AuthController;

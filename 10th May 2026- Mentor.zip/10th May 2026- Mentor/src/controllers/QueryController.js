const QueryModel = require("../models/Query");
const ActionLogModel = require("../models/ActionLog");

class QueryController {
  // Create query (Mentee)
  static async createQuery(req, res) {
    try {
      const {
        employeeName,
        employeeId,
        questionTitle,
        category,
        complexity,
        meetingType,
        preferredSlot,
        detailedQuery
      } = req.body;

      const queryData = {
        menteeId: req.user.id,
        menteeName: employeeName,
        menteeEmployeeId: employeeId,
        questionTitle,
        category,
        complexity,
        meetingType,
        preferredSlot,
        detailedQuery,
        status: "OPEN"
      };

      const newQuery = await QueryModel.createQuery(queryData);

      // Log the action
      await ActionLogModel.createLog({
        adminId: "SYSTEM",
        action: "QUERY_CREATED",
        queryId: newQuery.id,
        menteeId: req.user.id,
        details: `New query created: ${questionTitle}`
      });

      res.status(201).json({
        message: "Query submitted successfully",
        data: newQuery
      });
    } catch (error) {
      console.error("Error creating query:", error);
      res.status(500).json({ message: "Error creating query", error: error.message });
    }
  }

  // Get mentee's queries
  static async getMyQueries(req, res) {
    try {
      const queries = await QueryModel.getQueriesByMentee(req.user.id);
      res.status(200).json({
        message: "Queries fetched successfully",
        data: queries
      });
    } catch (error) {
      console.error("Error fetching queries:", error);
      res.status(500).json({ message: "Error fetching queries", error: error.message });
    }
  }

  // Get queries for mentor
  static async getMentorQueries(req, res) {
    try {
      const queries = await QueryModel.getQueriesByMentor(req.user.id);
      res.status(200).json({
        message: "Queries fetched successfully",
        data: queries
      });
    } catch (error) {
      console.error("Error fetching queries:", error);
      res.status(500).json({ message: "Error fetching queries", error: error.message });
    }
  }

  // Get all queries (Admin)
  static async getAllQueries(req, res) {
    try {
      const queries = await QueryModel.getAllQueries();
      res.status(200).json({
        message: "Queries fetched successfully",
        data: queries
      });
    } catch (error) {
      console.error("Error fetching queries:", error);
      res.status(500).json({ message: "Error fetching queries", error: error.message });
    }
  }

  // Assign query to mentor (Admin)
  static async assignQueryToMentor(req, res) {
    try {
      const { queryId, menteeId, mentorId } = req.body;

      const updatedQuery = await QueryModel.updateQuery(queryId, menteeId, {
        assignedMentorId: mentorId,
        status: "ASSIGNED"
      });

      await ActionLogModel.createLog({
        adminId: req.user.id,
        action: "QUERY_ASSIGNED",
        queryId: queryId,
        mentorId: mentorId,
        menteeId: menteeId,
        details: `Query assigned to mentor`
      });

      res.status(200).json({
        message: "Query assigned successfully",
        data: updatedQuery
      });
    } catch (error) {
      console.error("Error assigning query:", error);
      res.status(500).json({ message: "Error assigning query", error: error.message });
    }
  }

  // Add preferred slots (Mentor)
  static async addPreferredSlots(req, res) {
    try {
      const { queryId, menteeId, slots } = req.body;

      const updatedQuery = await QueryModel.updateQuery(queryId, menteeId, {
        mentorPreferredSlots: slots,
        status: "SLOTS_SHARED"
      });

      await ActionLogModel.createLog({
        adminId: req.user.id,
        action: "SLOTS_SHARED",
        queryId: queryId,
        mentorId: req.user.id,
        details: `Mentor shared preferred slots`
      });

      res.status(200).json({
        message: "Preferred slots shared successfully",
        data: updatedQuery
      });
    } catch (error) {
      console.error("Error adding slots:", error);
      res.status(500).json({ message: "Error adding slots", error: error.message });
    }
  }

  // Add resolution (Mentor)
  static async addResolution(req, res) {
    try {
      const { queryId, menteeId, resolution } = req.body;

      const updatedQuery = await QueryModel.updateQuery(queryId, menteeId, {
        resolution: resolution,
        resolutionProvidedAt: new Date().toISOString(),
        status: "RESOLVED"
      });

      await ActionLogModel.createLog({
        adminId: req.user.id,
        action: "RESOLUTION_PROVIDED",
        queryId: queryId,
        mentorId: req.user.id,
        details: `Mentor provided resolution`
      });

      res.status(200).json({
        message: "Resolution added successfully",
        data: updatedQuery
      });
    } catch (error) {
      console.error("Error adding resolution:", error);
      res.status(500).json({ message: "Error adding resolution", error: error.message });
    }
  }

  // Close query
  static async closeQuery(req, res) {
    try {
      const { queryId, menteeId, closingComments, closedBy } = req.body;

      const closureData = {
        closingComments,
        closedBy,
        closedAt: new Date().toISOString()
      };

      const updatedQuery = await QueryModel.closeQuery(queryId, menteeId, closureData);

      await ActionLogModel.createLog({
        adminId: req.user.id,
        action: "QUERY_CLOSED",
        queryId: queryId,
        menteeId: menteeId,
        details: `Query closed by ${closedBy}`
      });

      res.status(200).json({
        message: "Query closed successfully",
        data: updatedQuery
      });
    } catch (error) {
      console.error("Error closing query:", error);
      res.status(500).json({ message: "Error closing query", error: error.message });
    }
  }

  // Get analytics
  static async getAnalytics(req, res) {
    try {
      const analytics = await QueryModel.getAnalytics();
      res.status(200).json({
        message: "Analytics fetched successfully",
        data: analytics
      });
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Error fetching analytics", error: error.message });
    }
  }
}

module.exports = QueryController;

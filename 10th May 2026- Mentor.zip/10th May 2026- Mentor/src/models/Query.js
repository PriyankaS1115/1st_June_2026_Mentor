const { getFirestore } = require("../config/cosmosdb");
const { v4: uuidv4 } = require("uuid");

const COLLECTIONS = {
  QUERIES: "queries"
};

class QueryModel {
  // Create a new query
  static async createQuery(queryData) {
    try {
      const db = getFirestore();
      const newQuery = {
        id: uuidv4(),
        ...queryData,
        status: "OPEN",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await db.collection(COLLECTIONS.QUERIES).doc(newQuery.id).set(newQuery);
      return newQuery;
    } catch (error) {
      console.error("Error creating query:", error);
      throw error;
    }
  }

  // Get all queries
  static async getAllQueries() {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.QUERIES)
        .orderBy("createdAt", "desc")
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching queries:", error);
      throw error;
    }
  }

  // Get query by ID
  static async getQueryById(queryId) {
    try {
      const db = getFirestore();
      const queryDoc = await db.collection(COLLECTIONS.QUERIES).doc(queryId).get();

      if (!queryDoc.exists) {
        return null;
      }

      return { id: queryDoc.id, ...queryDoc.data() };
    } catch (error) {
      console.error("Error fetching query:", error);
      throw error;
    }
  }

  // Get queries by mentee
  static async getQueriesByMentee(menteeId) {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.QUERIES)
        .where("menteeId", "==", menteeId)
        .orderBy("createdAt", "desc")
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching queries:", error);
      throw error;
    }
  }

  // Get queries assigned to mentor
  static async getQueriesByMentor(mentorId) {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.QUERIES)
        .where("assignedMentorId", "==", mentorId)
        .orderBy("createdAt", "desc")
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching queries:", error);
      throw error;
    }
  }

  // Update query
  static async updateQuery(queryId, menteeId, updateData) {
    try {
      const db = getFirestore();
      const queryRef = db.collection(COLLECTIONS.QUERIES).doc(queryId);
      const queryDoc = await queryRef.get();

      if (!queryDoc.exists) {
        return null;
      }

      const updatedQuery = {
        ...queryDoc.data(),
        ...updateData,
        updatedAt: new Date().toISOString()
      };

      await queryRef.set(updatedQuery, { merge: true });
      return { id: queryId, ...updatedQuery };
    } catch (error) {
      console.error("Error updating query:", error);
      throw error;
    }
  }

  // Close query
  static async closeQuery(queryId, menteeId, closureData) {
    try {
      const db = getFirestore();
      const queryRef = db.collection(COLLECTIONS.QUERIES).doc(queryId);
      const queryDoc = await queryRef.get();

      if (!queryDoc.exists) {
        return null;
      }

      const closedQuery = {
        ...queryDoc.data(),
        status: "CLOSED",
        closedAt: new Date().toISOString(),
        ...closureData,
        updatedAt: new Date().toISOString()
      };

      await queryRef.set(closedQuery, { merge: true });
      return { id: queryId, ...closedQuery };
    } catch (error) {
      console.error("Error closing query:", error);
      throw error;
    }
  }

  // Get queries by status
  static async getQueriesByStatus(status) {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.QUERIES)
        .where("status", "==", status)
        .orderBy("createdAt", "desc")
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching queries:", error);
      throw error;
    }
  }

  // Get analytics data
  static async getAnalytics() {
    try {
      const db = getFirestore();
      const querySnapshot = await db.collection(COLLECTIONS.QUERIES).get();
      const analyticsMap = new Map();

      querySnapshot.docs.forEach((doc) => {
        const data = doc.data();
        const complexity = data.complexity || "UNKNOWN";
        const status = data.status || "UNKNOWN";
        const key = `${complexity}||${status}`;
        analyticsMap.set(key, (analyticsMap.get(key) || 0) + 1);
      });

      return Array.from(analyticsMap.entries()).map(([key, count]) => {
        const [complexity, status] = key.split("||");
        return { complexity, status, count };
      });
    } catch (error) {
      console.error("Error fetching analytics:", error);
      throw error;
    }
  }
}

module.exports = QueryModel;

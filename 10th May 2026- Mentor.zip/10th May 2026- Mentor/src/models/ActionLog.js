const { getFirestore } = require("../config/cosmosdb");
const { v4: uuidv4 } = require("uuid");

const COLLECTIONS = {
  ACTION_LOGS: "action_logs"
};

class ActionLogModel {
  // Create action log
  static async createLog(logData) {
    try {
      const db = getFirestore();
      const newLog = {
        id: uuidv4(),
        ...logData,
        createdAt: new Date().toISOString()
      };

      await db.collection(COLLECTIONS.ACTION_LOGS).doc(newLog.id).set(newLog);
      return newLog;
    } catch (error) {
      console.error("Error creating action log:", error);
      throw error;
    }
  }

  // Get logs by admin
  static async getLogsByAdmin(adminId) {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.ACTION_LOGS)
        .where("adminId", "==", adminId)
        .orderBy("createdAt", "desc")
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching logs:", error);
      throw error;
    }
  }

  // Get logs by query
  static async getLogsByQuery(queryId) {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.ACTION_LOGS)
        .where("queryId", "==", queryId)
        .orderBy("createdAt", "desc")
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching logs:", error);
      throw error;
    }
  }

  // Get all logs
  static async getAllLogs() {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.ACTION_LOGS)
        .orderBy("createdAt", "desc")
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching logs:", error);
      throw error;
    }
  }
}

module.exports = ActionLogModel;

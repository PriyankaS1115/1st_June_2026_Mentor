const { getFirestore } = require("../config/cosmosdb");
const { v4: uuidv4 } = require("uuid");
const bcrypt = require("bcryptjs");

const COLLECTIONS = {
  USERS: "users"
};

class UserModel {
  // Create user
  static async createUser(userData) {
    try {
      const db = getFirestore();
      const userId = uuidv4();

      const newUser = {
        id: userId,
        userId,
        ...userData,
        password: await bcrypt.hash(userData.password, 10),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await db.collection(COLLECTIONS.USERS).doc(userId).set(newUser);
      return newUser;
    } catch (error) {
      console.error("Error creating user:", error);
      throw error;
    }
  }

  // Get user by email
  static async getUserByEmail(email) {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.USERS)
        .where("email", "==", email)
        .limit(1)
        .get();

      if (querySnapshot.empty) {
        return null;
      }

      const userDoc = querySnapshot.docs[0];
      return { id: userDoc.id, ...userDoc.data() };
    } catch (error) {
      console.error("Error fetching user:", error);
      throw error;
    }
  }

  // Get user by ID
  static async getUserById(userId) {
    try {
      const db = getFirestore();
      const userDoc = await db.collection(COLLECTIONS.USERS).doc(userId).get();

      if (!userDoc.exists) {
        return null;
      }

      return { id: userDoc.id, ...userDoc.data() };
    } catch (error) {
      console.error("Error fetching user:", error);
      throw error;
    }
  }

  // Verify password
  static async verifyPassword(password, hashedPassword) {
    return bcrypt.compare(password, hashedPassword);
  }

  // Get all users by role
  static async getUsersByRole(role) {
    try {
      const db = getFirestore();
      const querySnapshot = await db
        .collection(COLLECTIONS.USERS)
        .where("role", "==", role)
        .get();

      return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Error fetching users:", error);
      throw error;
    }
  }

  // Update user
  static async updateUser(userId, updateData) {
    try {
      const db = getFirestore();
      const userRef = db.collection(COLLECTIONS.USERS).doc(userId);
      const userDoc = await userRef.get();

      if (!userDoc.exists) {
        return null;
      }

      const updatedUser = {
        ...userDoc.data(),
        ...updateData,
        updatedAt: new Date().toISOString()
      };

      await userRef.set(updatedUser, { merge: true });
      return updatedUser;
    } catch (error) {
      console.error("Error updating user:", error);
      throw error;
    }
  }
}

module.exports = UserModel;

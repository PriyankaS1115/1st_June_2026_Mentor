# 🔧 Complete NPM Install Troubleshooting Guide

## What is `npm install`?

`npm install` downloads all the libraries/packages your project needs. It reads `package.json` and installs everything listed there.

---

## ✅ Step 1: Check if Node.js is Installed

### On Windows (PowerShell):

1. **Open PowerShell as Administrator**
   - Right-click PowerShell → "Run as Administrator"

2. **Check Node version:**
   ```powershell
   node --version
   ```

3. **Check npm version:**
   ```powershell
   npm --version
   ```

### Expected Output:
```
v16.0.0  (or higher version)
8.0.0    (or higher version)
```

**If you see these versions, proceed to Step 2.**

### ❌ If Not Installed:

1. Go to [nodejs.org](https://nodejs.org/)
2. Download **LTS version** (recommended)
3. Run the installer
4. Click **Next** through all screens
5. **IMPORTANT**: Check "✓ Automatically install necessary tools"
6. Click **Install**
7. Wait for installation to complete
8. **Restart your computer**
9. Re-check versions in PowerShell

---

## ✅ Step 2: Navigate to Project Folder

### Using PowerShell:

1. **Open PowerShell** (not as admin, regular)

2. **Navigate to your project:**
   ```powershell
   cd "C:\Users\2000082692\OneDrive - Hexaware Technologies\vs code\10th May 2026- Mentor"
   ```

3. **Verify you're in correct folder:**
   ```powershell
   ls
   ```

   You should see:
   ```
   public/
   src/
   package.json
   README.md
   .env
   ...
   ```

**If you don't see these files, you're in wrong folder. Navigate to correct one.**

---

## ✅ Step 3: Clear npm Cache (Important!)

This fixes most issues:

```powershell
npm cache clean --force
```

Wait for it to complete.

---

## ✅ Step 4: Delete Old Node Modules (If Exists)

If you tried before and failed:

```powershell
rm -r node_modules
rm package-lock.json
```

---

## ✅ Step 5: Run npm install

Now run the actual install:

```powershell
npm install
```

This will:
1. Read `package.json`
2. Download ~200-300 packages
3. Takes 2-5 minutes
4. Shows progress bar

### Expected Output:
```
added 286 packages, and audited 287 packages in 2m 34s
```

**✅ If you see this, SUCCESS!**

---

## ❌ Troubleshooting Common Errors

### Error 1: "npm: The term 'npm' is not recognized"

**Cause:** Node.js not installed or not in PATH

**Fix:**
1. Download & reinstall Node.js from [nodejs.org](https://nodejs.org/)
2. **IMPORTANT**: Check "✓ Automatically install necessary tools"
3. Restart computer
4. Try again

### Error 2: "ERR! code ERESOLVE"

**Cause:** npm version conflict

**Fix:**
```powershell
npm cache clean --force
npm install --legacy-peer-deps
```

### Error 3: "ERR! ENOENT"

**Cause:** Wrong folder location

**Fix:**
```powershell
# Verify package.json exists
ls package.json

# If you see it, try again
npm install

# If you don't, navigate to correct folder
cd "C:\Users\2000082692\OneDrive - Hexaware Technologies\vs code\10th May 2026- Mentor"
```

### Error 4: "ERR! code EIO, i/o error"

**Cause:** Antivirus or permission issue

**Fix:**
```powershell
# Run as Administrator
npm install --verbose
```

### Error 5: "ETIMEDOUT" (Slow/No Internet)

**Cause:** Network timeout

**Fix:**
```powershell
# Increase timeout
npm install --timeout=120000

# Or use different npm registry
npm install --registry https://registry.npmmirror.com
```

### Error 6: "ERR! peer dep missing"

**Fix:**
```powershell
npm install --legacy-peer-deps
```

---

## ✅ Step 6: Verify Installation

After install completes, verify everything:

```powershell
# Check if node_modules folder exists
ls node_modules

# Should show many folders
```

You should see 280+ packages installed.

---

## ✅ Step 7: Test the Setup

Run the development server:

```powershell
npm run dev
```

You should see:
```
✓ Database initialized successfully
✓ Server running on http://localhost:3000
```

**If you see this, everything works! 🎉**

Open browser: `http://localhost:3000`

---

## 📋 Complete Step-by-Step Command List

Copy & paste these in order:

```powershell
# 1. Check versions
node --version
npm --version

# 2. Navigate to project
cd "C:\Users\2000082692\OneDrive - Hexaware Technologies\vs code\10th May 2026- Mentor"

# 3. Verify correct folder
ls

# 4. Clear cache
npm cache clean --force

# 5. Delete old modules (if exists)
rm -r node_modules
rm package-lock.json

# 6. Install dependencies (MAIN STEP)
npm install

# 7. Start server
npm run dev

# 8. Open browser: http://localhost:3000
```

---

## 🆘 Still Having Issues?

### Option 1: Alternative Installation Method

```powershell
# Try with npm ci (more stable)
npm ci
```

### Option 2: Clear Everything & Reinstall

```powershell
# Remove everything
rm -r node_modules
rm package-lock.json
rm -r %AppData%\npm-cache

# Clear npm cache
npm cache clean --force

# Install with verbose output
npm install --verbose
```

### Option 3: Use Different Terminal

Try **Git Bash** instead of PowerShell:
1. Install Git from [git-scm.com](https://git-scm.com/)
2. Right-click folder → "Git Bash Here"
3. Run: `npm install`

### Option 4: Check Antivirus

Sometimes antivirus blocks npm:
1. Temporarily disable antivirus
2. Run `npm install`
3. Re-enable antivirus

---

## ✅ Quick Checklist

- [ ] Node.js installed (`node --version` shows v14+)
- [ ] npm installed (`npm --version` shows v6+)
- [ ] In correct project folder (sees package.json)
- [ ] Cache cleared (`npm cache clean --force`)
- [ ] Old modules deleted (if tried before)
- [ ] Ran `npm install` successfully
- [ ] `node_modules` folder created (280+ packages)
- [ ] Can run `npm run dev`
- [ ] Server starts on http://localhost:3000

---

## 🆘 If Nothing Works

Copy this entire output and share with support:

```powershell
# Run this to diagnose
node --version
npm --version
npm config get registry
npm list
npm cache verify
```

---

## 📞 Still Stuck?

Try this manual approach:

1. **Delete entire project folder**
2. **Re-download/re-create it**
3. **Start from Step 1 again**

Or **Contact Support** with:
- Error message (full text)
- Output from diagnostic commands above
- Your Windows version

---

**99% of issues are solved by:**
1. Reinstalling Node.js
2. `npm cache clean --force`
3. `npm install`

Good luck! 🚀

const { v4: uuidv4 } = require("uuid");
const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

function verifyToken(req) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return null;
  
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

module.exports = async function (context, req) {
  context.log("AssignMentor function triggered");

  try {
    // Verify authentication
    const decoded = verifyToken(req);
    if (!decoded || decoded.role !== "ADMIN") {
      context.res = {
        status: 403,
        body: { message: "Access denied" }
      };
      return;
    }

    const { queryId, menteeId, mentorId } = req.body;

    if (!queryId || !menteeId || !mentorId) {
      context.res = {
        status: 400,
        body: { message: "Missing required fields" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();
    const queriesContainer = getContainer(CONTAINERS.QUERIES);
    const actionLogsContainer = getContainer(CONTAINERS.ACTION_LOGS);

    // Get existing query
    const { resource: existingQuery } = await queriesContainer.item(queryId, menteeId).read();

    // Update query
    const updatedQuery = {
      ...existingQuery,
      assignedMentorId: mentorId,
      status: "ASSIGNED",
      updatedAt: new Date().toISOString()
    };

    const { resource } = await queriesContainer.item(queryId, menteeId).replace(updatedQuery);

    // Log action
    const logEntry = {
      id: uuidv4(),
      adminId: decoded.userId,
      action: "QUERY_ASSIGNED",
      queryId: queryId,
      mentorId: mentorId,
      menteeId: menteeId,
      details: "Query assigned to mentor",
      createdAt: new Date().toISOString()
    };

    await actionLogsContainer.items.create(logEntry);

    context.res = {
      status: 200,
      body: {
        message: "Query assigned successfully",
        data: resource
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error assigning query",
        error: error.message
      }
    };
  }
};

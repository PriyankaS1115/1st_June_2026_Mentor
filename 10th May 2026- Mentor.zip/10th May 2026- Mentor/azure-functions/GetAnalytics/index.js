const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

function verifyToken(req) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return null;
  
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

module.exports = async function (context, req) {
  context.log("GetAnalytics function triggered");

  try {
    // Verify authentication
    const decoded = verifyToken(req);
    if (!decoded || !["ADMIN", "MENTOR"].includes(decoded.role)) {
      context.res = {
        status: 403,
        body: { message: "Access denied" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();
    const queriesContainer = getContainer(CONTAINERS.QUERIES);

    // Get all queries and compute analytics
    const { resources: allQueries } = await queriesContainer.items
      .query("SELECT * FROM c")
      .fetchAll();

    // Compute analytics
    const analytics = {};
    allQueries.forEach(query => {
      const key = `${query.complexity}-${query.status}`;
      analytics[key] = (analytics[key] || 0) + 1;
    });

    // Convert to array format
    const analyticsArray = Object.entries(analytics).map(([key, count]) => {
      const [complexity, status] = key.split("-");
      return { complexity, status, count };
    });

    context.res = {
      status: 200,
      body: {
        message: "Analytics fetched successfully",
        data: analyticsArray
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error fetching analytics",
        error: error.message
      }
    };
  }
};

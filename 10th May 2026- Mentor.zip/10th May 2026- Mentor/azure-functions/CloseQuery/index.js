const { v4: uuidv4 } = require("uuid");
const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

function verifyToken(req) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return null;
  
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

module.exports = async function (context, req) {
  context.log("CloseQuery function triggered");

  try {
    // Verify authentication
    const decoded = verifyToken(req);
    if (!decoded) {
      context.res = {
        status: 401,
        body: { message: "Unauthorized" }
      };
      return;
    }

    const { queryId, menteeId, closingComments, closedBy } = req.body;

    if (!queryId || !menteeId || !closingComments) {
      context.res = {
        status: 400,
        body: { message: "Missing required fields" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();
    const queriesContainer = getContainer(CONTAINERS.QUERIES);
    const actionLogsContainer = getContainer(CONTAINERS.ACTION_LOGS);

    // Get existing query
    const { resource: existingQuery } = await queriesContainer.item(queryId, menteeId).read();

    // Close query
    const closedQuery = {
      ...existingQuery,
      status: "CLOSED",
      closedAt: new Date().toISOString(),
      closingComments,
      closedBy,
      updatedAt: new Date().toISOString()
    };

    const { resource } = await queriesContainer.item(queryId, menteeId).replace(closedQuery);

    // Log action
    const logEntry = {
      id: uuidv4(),
      adminId: decoded.userId,
      action: "QUERY_CLOSED",
      queryId: queryId,
      menteeId: menteeId,
      details: `Query closed by ${closedBy}`,
      createdAt: new Date().toISOString()
    };

    await actionLogsContainer.items.create(logEntry);

    context.res = {
      status: 200,
      body: {
        message: "Query closed successfully",
        data: resource
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error closing query",
        error: error.message
      }
    };
  }
};

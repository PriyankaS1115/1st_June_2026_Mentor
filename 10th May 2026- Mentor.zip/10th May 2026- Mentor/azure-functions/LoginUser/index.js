const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

module.exports = async function (context, req) {
  context.log("LoginUser function triggered");

  try {
    const { email, password } = req.body;

    // Validation
    if (!email || !password) {
      context.res = {
        status: 400,
        body: { message: "Email and password required" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();

    // Get user by email
    const usersContainer = getContainer(CONTAINERS.USERS);
    const { resources: users } = await usersContainer.items
      .query("SELECT * FROM c WHERE c.email = @email", {
        parameters: [{ name: "@email", value: email }]
      })
      .fetchAll();

    if (users.length === 0) {
      context.res = {
        status: 401,
        body: { message: "Invalid credentials" }
      };
      return;
    }

    const user = users[0];

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      context.res = {
        status: 401,
        body: { message: "Invalid credentials" }
      };
      return;
    }

    // Create JWT token
    const token = jwt.sign(
      { userId: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user;

    context.res = {
      status: 200,
      body: {
        message: "Login successful",
        token,
        user: userWithoutPassword
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error logging in",
        error: error.message
      }
    };
  }
};

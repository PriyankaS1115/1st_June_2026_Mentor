const { v4: uuidv4 } = require("uuid");
const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

function verifyToken(req) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return null;
  
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

module.exports = async function (context, req) {
  context.log("AddSlots function triggered");

  try {
    // Verify authentication
    const decoded = verifyToken(req);
    if (!decoded || decoded.role !== "MENTOR") {
      context.res = {
        status: 403,
        body: { message: "Access denied" }
      };
      return;
    }

    const { queryId, menteeId, slots } = req.body;

    if (!queryId || !menteeId || !slots) {
      context.res = {
        status: 400,
        body: { message: "Missing required fields" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();
    const queriesContainer = getContainer(CONTAINERS.QUERIES);
    const actionLogsContainer = getContainer(CONTAINERS.ACTION_LOGS);

    // Get existing query
    const { resource: existingQuery } = await queriesContainer.item(queryId, menteeId).read();

    // Update query
    const updatedQuery = {
      ...existingQuery,
      mentorPreferredSlots: slots,
      status: "SLOTS_SHARED",
      updatedAt: new Date().toISOString()
    };

    const { resource } = await queriesContainer.item(queryId, menteeId).replace(updatedQuery);

    // Log action
    const logEntry = {
      id: uuidv4(),
      adminId: decoded.userId,
      action: "SLOTS_SHARED",
      queryId: queryId,
      details: "Mentor shared preferred slots",
      createdAt: new Date().toISOString()
    };

    await actionLogsContainer.items.create(logEntry);

    context.res = {
      status: 200,
      body: {
        message: "Preferred slots shared successfully",
        data: resource
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error adding slots",
        error: error.message
      }
    };
  }
};

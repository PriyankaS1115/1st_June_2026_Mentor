const { CosmosClient } = require("@azure/cosmos");

const endpoint = process.env.COSMOS_DB_ENDPOINT;
const key = process.env.COSMOS_DB_KEY;
const databaseId = process.env.COSMOS_DB_NAME;

let cosmosClient = null;
let database = null;

async function getDatabase() {
  if (!database) {
    cosmosClient = new CosmosClient({ endpoint, key });
    database = cosmosClient.database(databaseId);
  }
  return database;
}

function getContainer(containerName) {
  if (!database) {
    throw new Error("Database not initialized. Call getDatabase() first.");
  }
  return database.container(containerName);
}

const CONTAINERS = {
  QUERIES: "queries",
  MENTORS: "mentors",
  MENTEES: "mentees",
  ACTION_LOGS: "action_logs",
  USERS: "users"
};

module.exports = {
  getDatabase,
  getContainer,
  CONTAINERS
};

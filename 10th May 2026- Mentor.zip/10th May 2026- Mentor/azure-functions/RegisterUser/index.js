const { v4: uuidv4 } = require("uuid");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

module.exports = async function (context, req) {
  context.log("RegisterUser function triggered");

  try {
    const { email, password, name, employeeId, role, department } = req.body;

    // Validation
    if (!email || !password || !name || !role) {
      context.res = {
        status: 400,
        body: { message: "Missing required fields" }
      };
      return;
    }

    if (!["MENTEE", "MENTOR", "ADMIN"].includes(role)) {
      context.res = {
        status: 400,
        body: { message: "Invalid role" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();

    // Check if user exists
    const usersContainer = getContainer(CONTAINERS.USERS);
    const { resources: existingUsers } = await usersContainer.items
      .query("SELECT * FROM c WHERE c.email = @email", {
        parameters: [{ name: "@email", value: email }]
      })
      .fetchAll();

    if (existingUsers.length > 0) {
      context.res = {
        status: 400,
        body: { message: "User already exists" }
      };
      return;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const userId = uuidv4();
    const newUser = {
      id: userId,
      userId: userId,
      email,
      password: hashedPassword,
      name,
      employeeId,
      role,
      department,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const { resource: createdUser } = await usersContainer.items.create(newUser);

    // Create JWT token
    const token = jwt.sign(
      { userId: createdUser.id, role: createdUser.role },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    // Remove password from response
    const { password: _, ...userWithoutPassword } = createdUser;

    context.res = {
      status: 201,
      body: {
        message: "User registered successfully",
        token,
        user: userWithoutPassword
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error registering user",
        error: error.message
      }
    };
  }
};

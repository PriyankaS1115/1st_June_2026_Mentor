const { v4: uuidv4 } = require("uuid");
const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

function verifyToken(req) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return null;
  
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

module.exports = async function (context, req) {
  context.log("CreateQuery function triggered");

  try {
    // Verify authentication
    const decoded = verifyToken(req);
    if (!decoded) {
      context.res = {
        status: 401,
        body: { message: "Unauthorized" }
      };
      return;
    }

    const {
      employeeName,
      employeeId,
      questionTitle,
      category,
      complexity,
      meetingType,
      preferredSlot,
      detailedQuery
    } = req.body;

    // Validation
    if (!questionTitle || !category || !complexity || !detailedQuery) {
      context.res = {
        status: 400,
        body: { message: "Missing required fields" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();
    const queriesContainer = getContainer(CONTAINERS.QUERIES);
    const actionLogsContainer = getContainer(CONTAINERS.ACTION_LOGS);

    // Create query
    const queryId = uuidv4();
    const newQuery = {
      id: queryId,
      menteeId: decoded.userId,
      menteeName: employeeName,
      menteeEmployeeId: employeeId,
      questionTitle,
      category,
      complexity,
      meetingType,
      preferredSlot,
      detailedQuery,
      status: "OPEN",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const { resource: createdQuery } = await queriesContainer.items.create(newQuery);

    // Log action
    const logEntry = {
      id: uuidv4(),
      adminId: "SYSTEM",
      action: "QUERY_CREATED",
      queryId: createdQuery.id,
      menteeId: decoded.userId,
      details: `New query created: ${questionTitle}`,
      createdAt: new Date().toISOString()
    };

    await actionLogsContainer.items.create(logEntry);

    context.res = {
      status: 201,
      body: {
        message: "Query submitted successfully",
        data: createdQuery
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error creating query",
        error: error.message
      }
    };
  }
};

const jwt = require("jsonwebtoken");
const { getDatabase, getContainer, CONTAINERS } = require("../cosmosdb-utils");

function verifyToken(req) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return null;
  
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

module.exports = async function (context, req) {
  context.log("GetQueries function triggered");

  try {
    // Verify authentication
    const decoded = verifyToken(req);
    if (!decoded) {
      context.res = {
        status: 401,
        body: { message: "Unauthorized" }
      };
      return;
    }

    // Initialize database
    const db = await getDatabase();
    const queriesContainer = getContainer(CONTAINERS.QUERIES);

    const type = req.query.type || req.body.type;

    let queries;

    if (type === "my" && decoded.role === "MENTEE") {
      // Get mentee's queries
      const { resources } = await queriesContainer.items
        .query("SELECT * FROM c WHERE c.menteeId = @menteeId ORDER BY c.createdAt DESC", {
          parameters: [{ name: "@menteeId", value: decoded.userId }]
        })
        .fetchAll();
      queries = resources;
    } else if (type === "mentor" && decoded.role === "MENTOR") {
      // Get mentor's assigned queries
      const { resources } = await queriesContainer.items
        .query("SELECT * FROM c WHERE c.assignedMentorId = @mentorId ORDER BY c.createdAt DESC", {
          parameters: [{ name: "@mentorId", value: decoded.userId }]
        })
        .fetchAll();
      queries = resources;
    } else if (decoded.role === "ADMIN") {
      // Get all queries
      const { resources } = await queriesContainer.items
        .query("SELECT * FROM c ORDER BY c.createdAt DESC")
        .fetchAll();
      queries = resources;
    } else {
      context.res = {
        status: 403,
        body: { message: "Access denied" }
      };
      return;
    }

    context.res = {
      status: 200,
      body: {
        message: "Queries fetched successfully",
        data: queries
      }
    };
  } catch (error) {
    context.log("Error:", error);
    context.res = {
      status: 500,
      body: {
        message: "Error fetching queries",
        error: error.message
      }
    };
  }
};

#!/bin/bash

# ============================================
# Query Management System - Setup Script
# ============================================

echo ""
echo "========================================"
echo "Query Management System - Setup"
echo "========================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js is not installed!"
    echo "Please download and install from https://nodejs.org/"
    exit 1
fi

echo "[✓] Node.js is installed"
node --version

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "ERROR: npm is not installed!"
    exit 1
fi

echo "[✓] npm is installed"
npm --version
echo ""

# Install dependencies
echo "Installing dependencies..."
echo "Please wait, this may take 2-3 minutes..."
echo ""

npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi

echo ""
echo "========================================"
echo "[✓] Dependencies installed successfully!"
echo "========================================"
echo ""

# Check for .env file
if [ ! -f ".env" ]; then
    echo ""
    echo "WARNING: .env file not found!"
    echo ""
    echo "Please follow these steps:"
    echo ""
    echo "1. Go to https://portal.azure.com/"
    echo "2. Create or open your Cosmos DB account"
    echo "3. Go to Keys section"
    echo "4. Copy your URI and Primary Key"
    echo "5. Open .env file and update:"
    echo "   COSMOS_DB_ENDPOINT=your-uri-here"
    echo "   COSMOS_DB_KEY=your-key-here"
    echo ""
    echo "Detailed guide: See AZURE-SETUP.md"
    echo ""
else
    echo "[✓] .env file found"
fi

echo ""
echo "========================================"
echo "Setup Complete!"
echo "========================================"
echo ""
echo "Next steps:"
echo "1. Update .env with your Cosmos DB credentials"
echo "2. Run: npm run dev"
echo "3. Open: http://localhost:3000"
echo ""
echo "For detailed setup guide, see:"
echo "- QUICK-START.md"
echo "- AZURE-SETUP.md"
echo "- README.md"
echo ""

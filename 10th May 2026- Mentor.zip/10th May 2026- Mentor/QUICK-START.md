## 🚀 Quick Start Guide - Query Management System

### ⚡ 5-Minute Setup

#### 1. **Download & Open Project**
```bash
# Navigate to project folder
cd "path/to/Query-Management-System"

# Open in VS Code
code .
```

#### 2. **Install Dependencies**
```bash
npm install
```
Wait for installation to complete (2-3 minutes)

#### 3. **Configure Azure Cosmos DB**

**Get your credentials:**
1. Go to [Azure Portal](https://portal.azure.com/)
2. Select your Cosmos DB account
3. Click **Keys** in left sidebar
4. Copy: **URI** and **PRIMARY KEY**

**Update .env file:**
1. Open `.env` in project root
2. Replace placeholders:
```env
COSMOS_DB_ENDPOINT=https://YOUR-ACCOUNT.documents.azure.com:443/
COSMOS_DB_KEY=YOUR_PRIMARY_KEY
```
3. Save file

#### 4. **Start Server**
```bash
npm run dev
```

You should see:
```
✓ Database initialized successfully
✓ Server running on http://localhost:3000
```

#### 5. **Open in Browser**
```
http://localhost:3000
```

---

### 🔑 Test Credentials

Create test accounts by registering:

**Mentee Account:**
- Email: `mentee@test.com`
- Password: `Test123`
- Role: Mentee

**Mentor Account:**
- Email: `mentor@test.com`
- Password: `Test123`
- Role: Mentor

**Admin Account:**
- Email: `admin@test.com`
- Password: `Test123`
- Role: Admin

---

### 📝 What Each Role Can Do

**MENTEE** 👨‍🎓
- Submit queries with detailed description
- Track query status
- View mentor's resolution

**MENTOR** 👨‍🏫
- See assigned queries
- Share preferred meeting slots
- Provide resolution
- View dashboard analytics

**ADMIN** 👨‍💼
- View all queries
- Assign mentors to queries
- Close queries
- Access comprehensive analytics

---

### 📊 Example Query Workflow

1. **Mentee submits query:**
   - Click "Submit New Query"
   - Fill details (title, category, complexity, etc.)
   - Click "Submit Query"

2. **Admin assigns mentor:**
   - Go to Query Management
   - Find the query
   - Click "Assign Mentor"
   - Select mentor and assign

3. **Mentor responds:**
   - Login as mentor
   - See assigned query
   - Click "Share Slots" for meeting times
   - Click "Add Resolution" with solution
   - Optionally "Close Query"

4. **Admin closes:**
   - Verify resolution provided
   - Add closing comments
   - Mark as "CLOSED"

---

### 🧪 Testing APIs

Use REST Client extension:

1. **Install Extension:**
   - Ctrl+Shift+X → Search "REST Client" → Install

2. **Test Requests:**
   - Open `test-api.rest` file
   - Right-click any request → "Send Request"
   - View response

3. **Sample Request:**
```http
POST http://localhost:3000/api/auth/login
Content-Type: application/json

{
  "email": "mentee@test.com",
  "password": "Test123"
}
```

---

### 🛠️ VS Code Extensions to Install

Press `Ctrl+Shift+X` and search for:

1. ✅ **REST Client** - Test API endpoints
2. ✅ **Azure Cosmos DB** - Manage database
3. ✅ **Prettier** - Format code
4. ✅ **ESLint** - Code quality
5. ✅ **Thunder Client** - Alternative API tester

---

### 📂 Project File Structure

```
│── public/
│   ├── index.html          👈 Main app
│   ├── css/styles.css      👈 Professional styling
│   └── js/                 👈 Frontend logic
│
├── src/
│   ├── server.js           👈 Start here
│   ├── config/cosmosdb.js  👈 Database setup
│   ├── models/             👈 Data models
│   ├── controllers/        👈 Business logic
│   ├── routes/             👈 API endpoints
│   └── middleware/         👈 Auth & validation
│
├── .env                    👈 Your secrets (update this)
├── package.json            👈 Dependencies
├── test-api.rest           👈 API testing
└── README.md               👈 Full documentation
```

---

### ⚠️ Common Issues & Fixes

**Issue: "Cannot find module"**
```bash
# Fix: Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

**Issue: "Port 3000 already in use"**
```bash
# Edit .env and change:
PORT=3001
```

**Issue: "Cosmos DB connection failed"**
- Verify .env credentials
- Check if Cosmos DB is running
- Ensure firewall allows access

**Issue: "Blank page on browser"**
- Check browser console (F12 → Console)
- Verify server is running
- Clear browser cache

---

### 🔗 Useful Links

- [Azure Cosmos DB](https://azure.microsoft.com/services/cosmos-db/)
- [Node.js Docs](https://nodejs.org/docs/)
- [Express Guide](https://expressjs.com/)
- [JWT.io](https://jwt.io/)

---

### 📞 Next Steps

1. ✅ Complete setup above
2. ✅ Create test accounts
3. ✅ Test mentee → submit query
4. ✅ Test admin → assign mentor
5. ✅ Test mentor → provide resolution
6. ✅ Explore admin dashboard analytics

---

**You're ready to go! Start the server and enjoy! 🎉**

For detailed info, see [README.md](./README.md)
